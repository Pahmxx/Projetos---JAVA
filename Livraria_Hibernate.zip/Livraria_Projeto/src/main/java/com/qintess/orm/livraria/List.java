package com.qintess.orm.livraria;

import java.util.Scanner;

import com.qintess.orm.livraria.dao.AutoresDao;
import com.qintess.orm.livraria.dao.EdicaoDao;
import com.qintess.orm.livraria.dao.EditorasDao;
import com.qintess.orm.livraria.dao.EstoqueDao;
import com.qintess.orm.livraria.dao.LivrosDao;
import com.qintess.orm.livraria.entidades.Autores;
import com.qintess.orm.livraria.entidades.Edicao;
import com.qintess.orm.livraria.entidades.Editoras;
import com.qintess.orm.livraria.entidades.Estoque;
import com.qintess.orm.livraria.entidades.Livros;


public class List {

	Autores autores = new Autores();
	AutoresDao daoAutores = new AutoresDao();

	Edicao edicao = new Edicao();
	EdicaoDao daoEdicao = new EdicaoDao();

	Editoras editoras = new Editoras();
	EditorasDao daoEditoras = new EditorasDao();
	
	Livros livros = new Livros();
	LivrosDao daoLivros = new LivrosDao();
	
	Estoque estoque = new Estoque();
	EstoqueDao daoEstoque = new EstoqueDao();
	
	public void list( ) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Deseja listar: \r\n"
				+ "1 = Autores \r\n"
				+ "2 = Edicões \r\n"
				+ "3 = Editoras \r\n"
				+ "4 = Estoque \r\n"
				+ "5 = Livros \r\n"
				);

		int escolha = sc.nextInt();

		System.out.println("===== LIST ===== ");

		if (escolha == 1) {
			daoAutores.buscaTodos().forEach(System.out::println);
			
		} if (escolha == 2) {
			daoEdicao.buscaTodos().forEach(System.out::println);
			
		} if (escolha == 3) {
			daoEditoras.buscaTodos().forEach(System.out::println);
			
		} if (escolha == 4) {
			daoEstoque.buscaTodos().forEach(System.out::println);
			
		} if (escolha == 5) {
			daoLivros.buscaTodos().forEach(System.out::println);
			
		}
	}
}