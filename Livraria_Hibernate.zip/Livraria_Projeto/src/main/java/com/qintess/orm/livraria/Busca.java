package com.qintess.orm.livraria;

import java.util.Scanner;

import com.qintess.orm.livraria.dao.AutoresDao;
import com.qintess.orm.livraria.dao.EdicaoDao;
import com.qintess.orm.livraria.dao.EditorasDao;
import com.qintess.orm.livraria.dao.EstoqueDao;
import com.qintess.orm.livraria.dao.LivrosDao;

public class Busca {

	public void busca( ) {

		AutoresDao daoAutores = new AutoresDao();
		EdicaoDao daoEdicao = new EdicaoDao();;
		EditorasDao daoEditoras = new EditorasDao();
		LivrosDao daoLivros = new LivrosDao();
		EstoqueDao daoEstoque = new EstoqueDao();
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Deseja buscar por: \r\n"
				+ "1 = ID \r\n"
				+ "2 = Nome \r\n"
				);

		int escolha1 = sc.nextInt();

		if (escolha1 == 1 ) {

			System.out.println("Deseja buscar: \r\n"
					+ "1 = Autores \r\n"
					+ "2 = Editoras \r\n"
					+ "3 = Edicões \r\n"
					+ "4 = Livros \r\n"
					+ "5 = Estoque \r\n"
					);

			int escolha2 = sc.nextInt();

			if (escolha2 == 1) {
				System.out.print("Digite o ID a ser buscado: ");
				int id = sc.nextInt();
				System.out.println(daoAutores.buscaPorId(id));

			} if (escolha2 == 2) {
				System.out.print("Digite o ID a ser buscado: ");
				int id = sc.nextInt();
				System.out.println(daoEditoras.buscaPorId(id));

			} if (escolha2 == 3) {
				System.out.print("Digite o ID a ser buscado: ");
				int id = sc.nextInt();
				System.out.println(daoEdicao.buscaPorId(id));

			} if (escolha2 == 4) {
				System.out.print("Digite o ID a ser buscado: ");
				int id = sc.nextInt();
				System.out.println(daoLivros.buscaPorId(id));
				
			} if (escolha2 == 5) {
				System.out.print("Digite o ID a ser buscado: ");
				int id = sc.nextInt();
				System.out.println(daoEstoque.buscaPorId(id));
			}


		} if (escolha1 == 2 ) {

			System.out.println("Deseja buscar: \r\n"
					+ "1 = Autores \r\n"
					+ "2 = Editoras \r\n"
					+ "3 = Edicões \r\n"
					+ "4 = Livros \r\n"
					);

			int escolha3 = sc.nextInt();

			if (escolha3 == 1) {
				System.out.print("Digite o nome a ser buscado: ");
				String nome = sc.next();
				System.out.println(daoAutores.buscaPorNome(nome));

			} if (escolha3 == 2) {
				System.out.print("Digite o nome a ser buscado: ");
				String nome = sc.next();
				System.out.println(daoEditoras.buscaPorNome(nome));

			} if (escolha3 == 3) {
				System.out.print("Digite o nome a ser buscado: ");
				String nome = sc.next();
				System.out.println(daoEdicao.buscaPorNome(nome));

			} if (escolha3 == 4) {
				System.out.print("Digite o nome a ser buscado: ");
				String nome = sc.next();
				System.out.println(daoLivros.buscaPorNome(nome));
			}
		}
	}
}