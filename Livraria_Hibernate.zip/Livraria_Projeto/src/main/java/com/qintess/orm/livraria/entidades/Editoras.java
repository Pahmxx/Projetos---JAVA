package com.qintess.orm.livraria.entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Editoras {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_editora;
	
	@Column(length = 45)
	private String nome;
	
	@Column(length = 20)
	private String telefone;
	
	@OneToOne
	private Endereco endereco;

	public int getId_editora() {
		return id_editora;
	}

	public void setId_editora(int id_editora) {
		this.id_editora = id_editora;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}


	@Override
	public String toString() {
		return "Editoras [ID_editora= " + id_editora + ", Nome= " + nome + ", Telefone= " + telefone + endereco;
	}
	
	
}
