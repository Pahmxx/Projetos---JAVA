package com.qintess.orm.livraria.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;

import com.qintess.orm.livraria.entidades.Autores;


public class AutoresDao {


	@PersistenceUnit
	private EntityManagerFactory emf;

	public  AutoresDao () {

		emf = Persistence.createEntityManagerFactory("qintess");

	}

	public Autores insere(Autores autores) {

		EntityManager em = emf.createEntityManager();

		try {

			em.getTransaction().begin();

			em.persist(autores);

			em.getTransaction().commit();

			em.close();


		} catch (Exception e) {
			System.err.println(e);

		}

		return autores;
	}

	public List <Autores> buscaTodos() {

		List <Autores> autores = new ArrayList <Autores>();

		try {

			EntityManager em = emf.createEntityManager();	
			autores = em.createQuery("select a from Autores a", Autores.class).getResultList();	


		} catch (Exception e) {
			e.printStackTrace();

		}

		return autores;
	}

	public Autores buscaPorId (int id) {

		Autores autores = new Autores();

		try {

			EntityManager em = emf.createEntityManager();
			autores = em.find(Autores.class,id);	

		} catch (Exception e) {		
			e.printStackTrace();
		}

		return autores;
	}

	public Autores buscaPorNome (String nome_autores) {

		Autores ret = new Autores ();

		try {

			EntityManager em = emf.createEntityManager();	
			ret = em.createQuery("select a from Autores a where a.nome_autores=:nome_autores", Autores.class)
					.setParameter("nome_autores", nome_autores)
					.setMaxResults(1)
					.getSingleResult();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

}









