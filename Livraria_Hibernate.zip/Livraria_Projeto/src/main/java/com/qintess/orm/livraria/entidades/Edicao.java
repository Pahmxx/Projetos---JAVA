package com.qintess.orm.livraria.entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Edicao {
	
	@Id
	private int isbn;
	
	@Column(precision=3, scale=2)
	private double preco;
	
	private int ano;	
	private int pag;
	
	@ManyToOne
	private Estoque estoque;
	
	@ManyToOne
	private Livros livros;
	
	@ManyToOne
	private Editoras Editoras;

	public int getIsbn() {
		return isbn;
	}

	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public int getPag() {
		return pag;
	}

	public void setPag(int pag) {
		this.pag = pag;
	}

	public Estoque getEstoque() {
		return estoque;
	}

	public void setEstoque(Estoque estoque) {
		this.estoque = estoque;
	}

	public Livros getLivros() {
		return livros;
	}

	public void setLivros(Livros livros) {
		this.livros = livros;
	}

	public Editoras getEditoras() {
		return Editoras;
	}

	public void setEditoras(Editoras editoras) {
		this.Editoras = editoras;
	}

	@Override
	public String toString() {
		return "Edicao [isbn=" + isbn + ", preco=" + preco + ", ano=" + ano + ", pag=" + pag + ", estoque=" + estoque
				+ ", livros=" + livros + ", Editoras=" + Editoras + "]";
	}
	
	
	
}
