package com.qintess.orm.livraria.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;

import com.qintess.orm.livraria.entidades.Endereco;

public class EnderecoDao {
	
	@PersistenceUnit
	private EntityManagerFactory emf;
	
	public  EnderecoDao () {

		emf = Persistence.createEntityManagerFactory("qintess");
		
	}
	 
	public Endereco insere(Endereco endereco) {
		
		EntityManager em = emf.createEntityManager();
		
		try {
						
			em.getTransaction().begin();
			
			em.persist(endereco);
			
			em.getTransaction().commit();
			
//			em.getTransaction().rollback();

			em.close();

						
		} catch (Exception e) {
			System.err.println(e);

		}

		return endereco;
	}

}
