package com.qintess.orm.livraria.entidades;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Livros {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cod;
	
	@Column(length = 45)
	private String nome_livro;
	
	@Column(length = 15)
	private String idioma;
	
	private int ano;
	
	@OneToOne
	private Editoras editoras;
	
	
	@ManyToMany
	private List <Autores> autores = new ArrayList <Autores>();
	
	public int getCod() {
		return cod;
	}

	public void setCod(int cod) {
		this.cod = cod;
	}

	public String getNome_livro() {
		return nome_livro;
	}

	public void setNome_livro(String nome_livro) {
		this.nome_livro = nome_livro;
	}

	public String getIdioma() {
		return idioma;
	}

	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public List<Autores> getAutores() {
		return autores;
	}

	public void setAutores(List<Autores> autores) {
		this.autores = autores;
	}

	public Editoras getEditoras() {
		return editoras;
	}

	public void setEditoras(Editoras editoras) {
		this.editoras = editoras;
	}

	@Override
	public String toString() {
		return "Livros [cod=" + cod + ", nome_livro=" + nome_livro + ", idioma=" + idioma + ", ano=" + ano
				+ ", editoras=" + editoras + ", autores=" + autores + "]";
	}

}
