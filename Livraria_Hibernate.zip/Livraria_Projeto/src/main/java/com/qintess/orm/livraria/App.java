package com.qintess.orm.livraria;

import java.text.ParseException;
import java.util.Scanner;

public class App {


	public static void main( String[] args ) throws ParseException

	{
		Compra compra = new Compra();
		Venda venda = new Venda();
		List list = new List ();
		Busca busca = new Busca();
		Relatorios relatorios = new Relatorios();
		
		Scanner sc = new Scanner(System.in);

		System.out.println ("Digite a operação desejada");
		System.out.println ("1 = Compra \r\n" //INSERIR O LIVRO - INSERE AUTOR - INSERE EDITORA - INSERE EDICAO | ATUALIZAR O ESTOQUE 
				          + "2 = Venda \r\n" // SUBTRAI QUANTIDADE ESTOQUE 
				          + "3 = Exibir produtos \r\n" // LIST
                          + "4 = Buscar produtos \r\n" // BUSCA POR ID / NOME
                          + "5 = Relatórios \r\n"); 

		int escolha = sc.nextInt();

		if (escolha == 1) {
			compra.compra();

		} if (escolha == 2 ) {
			venda.venda();
			
		} if (escolha == 3) {
			list.list();
			
		} if (escolha == 4) {
			busca.busca();
			
		} if (escolha == 5) {
			relatorios.relatorios();
		}
	}
}