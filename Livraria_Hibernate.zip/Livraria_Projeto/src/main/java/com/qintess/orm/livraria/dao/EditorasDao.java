package com.qintess.orm.livraria.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;

import com.qintess.orm.livraria.entidades.Editoras;

public class EditorasDao {
	
	@PersistenceUnit
	private EntityManagerFactory emf;
	
	public  EditorasDao () {

		emf = Persistence.createEntityManagerFactory("qintess");
		
	}
	 
	public Editoras insere(Editoras editoras) {
		
		EntityManager em = emf.createEntityManager();
		
		try {
						
			em.getTransaction().begin();
			
			em.persist(editoras);
			
			em.getTransaction().commit();

			em.close();

						
		} catch (Exception e) {
			System.err.println(e);

		}

		return editoras;
	}
	
	public List <Editoras> buscaTodos() {

		List <Editoras> editoras = new ArrayList <Editoras>();

		try {

			EntityManager em = emf.createEntityManager();	
			editoras = em.createQuery("select e from Editoras e", Editoras.class).getResultList();	

		} catch (Exception e) {

		}
		
		return editoras;
	}

	public Editoras buscaPorId (int id) {

		Editoras editoras = new Editoras();

		try {

			EntityManager em = emf.createEntityManager();
			editoras = em.find(Editoras.class,id);	

		} catch (Exception e) {		
			e.printStackTrace();
		}

		return editoras;
	}
	
	public Editoras buscaPorNome (String nome) {

		Editoras ret = new Editoras ();

		try {

			EntityManager em = emf.createEntityManager();	
			ret = em.createQuery("select e from Editoras e where e.nome= :nome", Editoras.class)
			.setParameter("nome", nome)
			.setMaxResults(1)
			.getSingleResult();
		
		} catch (Exception e) {

				}
		
		return ret;
	}
	
	
	
	
}
