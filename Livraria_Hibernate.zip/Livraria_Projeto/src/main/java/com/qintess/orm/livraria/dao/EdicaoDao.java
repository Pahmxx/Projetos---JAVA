package com.qintess.orm.livraria.dao;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;

import com.qintess.orm.livraria.entidades.Edicao;
import com.qintess.orm.livraria.entidades.Estoque;

public class EdicaoDao {
	
	@PersistenceUnit
	private EntityManagerFactory emf;
	
	public  EdicaoDao () {

		emf = Persistence.createEntityManagerFactory("qintess");
		
	}
	 
	public Edicao insere(Edicao edicao) {

		EntityManager em = emf.createEntityManager();

		try {
			
			em.getTransaction().begin();

			em.persist(edicao);

			em.getTransaction().commit();

			em.close();


		} catch (Exception e) {
			e.printStackTrace();

		} 

		return edicao;
	}

	public Object buscaMenor() {

		Object ret = null;

		try {

			EntityManager em = emf.createEntityManager();	
			ret = em.createNativeQuery("SELECT isbn, ano, pag, preco, editoras_id_editora, livros_cod, estoque_id_estoque FROM edicao WHERE preco = (SELECT MIN(preco) FROM edicao)", Edicao.class).getSingleResult();

		} catch (Exception e) {

		}
		
		return ret;
	}

	public void estoque () {


	}	  
	
	public int compraLivro() {

		int estoque = 0;

		try {

			EntityManager em = emf.createEntityManager();	
			estoque = em.createQuery("SELECT COUNT (*) EDICAO", Estoque.class).getResultList().size();	
		} catch (Exception e) {

		}

		return estoque;
	}
	
	public List <Edicao> buscaTodos() {

		List <Edicao> edicao = new ArrayList <Edicao>();

		try {

			EntityManager em = emf.createEntityManager();	
			edicao = em.createQuery("select e from Edicao e", Edicao.class).getResultList();	

		} catch (Exception e) {

		}
		
		return edicao;
	}
	
	public Edicao buscaPorId (int id) {

		Edicao edicao = new Edicao();

		try {

			EntityManager em = emf.createEntityManager();
			edicao = em.find(Edicao.class,id);	

		} catch (Exception e) {		
			e.printStackTrace();
		}

		return edicao;
	}
	
	public Edicao buscaPorNome (String nome) {

		Edicao ret = new Edicao ();

		try {

			EntityManager em = emf.createEntityManager();	
			ret = em.createQuery("select a from Edicao a where a.nome= :nome", Edicao.class)
			.setParameter("nome", nome)
			.setMaxResults(1)
			.getSingleResult();
		
		} catch (Exception e) {

				}
		
		return ret;
	}
	
public void altera (Edicao edicao) {
		
		try {
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.merge(edicao);
			em.getTransaction().commit();
			em.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}	  
	 



