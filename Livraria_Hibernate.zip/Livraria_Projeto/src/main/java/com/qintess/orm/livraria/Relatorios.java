package com.qintess.orm.livraria;

import java.util.Scanner;

import com.qintess.orm.livraria.dao.EdicaoDao;
import com.qintess.orm.livraria.dao.LivrosDao;

public class Relatorios {


	public void relatorios( ) {

		EdicaoDao daoEdicao = new EdicaoDao();;
		LivrosDao daoLivros = new LivrosDao();

		Scanner sc = new Scanner(System.in);

		System.out.println("Digite a operação desejada: ");
		System.out.println ("1 = Retornar os livros com sua editora e autores preenchidos \r\n" 
				+ "2 = Retornar os livros que um autor escreveu \r\n" 
				+ "3 = Retornar a edição mais barata \r\n" 
				); 

		int escolha = sc.nextInt();

		if (escolha == 1) {
			System.out.println(daoLivros.buscaTodosRelatorio());

		} if (escolha == 2) {
			System.out.println("Digite o nome do autor: ");
			String nomeAutor = sc.next();
			System.out.println(daoLivros.buscaTodosAutor(nomeAutor));
			
		} if (escolha == 3) {
			System.out.println(daoEdicao.buscaMenor());
		}
	}
}