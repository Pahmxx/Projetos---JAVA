package com.qintess.orm.livraria.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;

import com.qintess.orm.livraria.entidades.Edicao;
import com.qintess.orm.livraria.entidades.Editoras;
import com.qintess.orm.livraria.entidades.Estoque;
import com.qintess.orm.livraria.entidades.Livros;

public class LivrosDao {
	
	@PersistenceUnit
	private EntityManagerFactory emf;
	
	public  LivrosDao () {

		emf = Persistence.createEntityManagerFactory("qintess");
		
	}
	 
	public Livros insere(Livros livros) {
		
		EntityManager em = emf.createEntityManager();
		
		try {
						
			em.getTransaction().begin();
			
			em.persist(livros);
			
			em.getTransaction().commit();

			em.close();

						
		} catch (Exception e) {
			System.err.println(e);

		}

		return livros;
	}
	
	public List <Livros> buscaTodosRelatorio() {

		List <Livros> livro = new ArrayList <Livros>();

		try {

			EntityManager em = emf.createEntityManager();	
			livro = em.createNativeQuery("SELECT nome_livro, nome_autores, nome FROM editoras, livros, autores", Livros.class).getResultList();	

		} catch (Exception e) {	

		}

		return livro;
	}
	
	public List <Livros> buscaTodosAutor(String nome_autores) {

		List <Livros> livro = new ArrayList <Livros>();

		try {

			EntityManager em = emf.createEntityManager();	
			
			List resultList = em.createNativeQuery("SELECT *"
					+ "FROM LIVROS_AUTORES \r\n"
					+ "LEFT JOIN  LIVROS\r\n"
					+ "ON LIVROS.COD = LIVROS_AUTORES.LIVROS_COD\r\n"
					+ "LEFT JOIN  AUTORES \r\n"
					+ "ON AUTORES.ID_AUTORES = LIVROS_AUTORES.AUTORES_ID_AUTORES \r\n"
					+ "WHERE NOME_AUTORES = :nome_autores", Livros.class)
					.setParameter("nome_autores", nome_autores)
					.getResultList();
			
			livro = resultList;



		} catch (Exception e) {	
			 e.printStackTrace();
		}

		return livro;
	}
	
	public List <Livros> buscaTodos() {

		List <Livros> livros = new ArrayList <Livros>();

		try {

			EntityManager em = emf.createEntityManager();	
			livros = em.createQuery("select l from Livros l", Livros.class).getResultList();	

		} catch (Exception e) {

		}
		
		return livros;
	}
	
	public Livros buscaPorId (int id) {

		Livros livros = new Livros();

		try {

			EntityManager em = emf.createEntityManager();
			livros = em.find(Livros.class,id);	

		} catch (Exception e) {		
			e.printStackTrace();
		}

		return livros;
	}
	
	public Livros buscaPorNome (String nome_livro) {

		Livros ret = new Livros ();

		try {

			EntityManager em = emf.createEntityManager();	
			ret = em.createQuery("select a from Livros a where a.nome_livro= :nome_livro", Livros.class)
			.setParameter("nome_livro", nome_livro)
			.setMaxResults(1)
			.getSingleResult();
		
		} catch (Exception e) {

				}
		
		return ret;
	}
	
	public void altera (Livros livros) {

		try {
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.merge(livros);
			em.getTransaction().commit();
			em.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public List <Livros> buscaEdicao() {

		List <Livros> livro = new ArrayList <Livros>();

		try {

			EntityManager em = emf.createEntityManager();	
			
			List resultList = em.createNativeQuery("SELECT EDICAO.ISBN,\r\n"
					+ "       ESTOQUE.ID_ESTOQUE\r\n"
					+ "FROM EDICAO\r\n"
					+ "LEFT JOIN  ESTOQUE\r\n"
					+ "ON EDICAO.ESTOQUE_ID_ESTOQUE = ESTOQUE.ID_ESTOQUE", Livros.class).getResultList();
			
			livro = resultList;

		} catch (Exception e) {	
			 e.printStackTrace();
		}
		
		return livro;
	
}
}