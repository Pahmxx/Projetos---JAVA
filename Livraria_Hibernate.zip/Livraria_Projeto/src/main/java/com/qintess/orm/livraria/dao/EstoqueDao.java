package com.qintess.orm.livraria.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;

import com.qintess.orm.livraria.entidades.Estoque;

public class EstoqueDao {

	@PersistenceUnit
	private EntityManagerFactory emf;

	public  EstoqueDao () {

		emf = Persistence.createEntityManagerFactory("qintess");

	}

	public Estoque insere (Estoque estoque) {

		try {
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(estoque);
			em.getTransaction().commit();
			em.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return estoque;
	}


	public void vendeLivro(Estoque estoque) {

		try {
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			estoque = em.merge(estoque);
			em.remove(estoque);
			em.getTransaction().commit();
			em.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Object quantEstoque(Object estoque) {

		try {

			EntityManager em = emf.createEntityManager();	
			estoque = em.createNativeQuery("select sum(m.quantidade_estoque) from estoque m", Estoque.class).getSingleResult();	
		} catch (Exception e) {

		}

		return estoque;
	}

	public List <Estoque> buscaTodos() {

		List <Estoque> estoques = new ArrayList <Estoque>();

		try {

			EntityManager em = emf.createEntityManager();	
			estoques = em.createQuery("select e from Estoque e", Estoque.class).getResultList();	

		} catch (Exception e) {

		}

		return estoques;
	}

	public Estoque buscaPorId (int id) {

		Estoque estoques = new Estoque();

		try {

			EntityManager em = emf.createEntityManager();
			estoques = em.find(Estoque.class,id);	

		} catch (Exception e) {		
			e.printStackTrace();
		}

		return estoques;
	}


	public void altera (Estoque estoque) {

		try {
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.merge(estoque);
			em.getTransaction().commit();
			em.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Estoque alteraQuantSub(int id_estoque, int quant) {

		Estoque estoque = new Estoque();

		try {

			EntityManager em = emf.createEntityManager();	
			estoque = em.createQuery("UPDATE ESTOQUE e SET QUANTIDADE_ESTOQUE = QUANTIDADE_ESTOQUE - :quant WHERE e.ID_ESTOQUE = :id_estoque", Estoque.class)
					.setParameter("id_estoque", id_estoque)
					.setParameter("quant", quant)
					.setMaxResults(1)
					.getSingleResult();	

		} catch (Exception e) {

		}

		return estoque;
	}
	
	public Estoque alteraQuantSoma(int id_estoque, int quant) {

		Estoque estoque = new Estoque();

		try {

			EntityManager em = emf.createEntityManager();	
			estoque = em.createQuery("UPDATE ESTOQUE e SET QUANTIDADE_ESTOQUE = QUANTIDADE_ESTOQUE + :quant WHERE e.ID_ESTOQUE = :id_estoque", Estoque.class)
					.setParameter("id_estoque", id_estoque)
					.setParameter("quant", quant)
					.setMaxResults(1)
					.getSingleResult();	

		} catch (Exception e) {

		}

		return estoque;
	}

}

	
	
