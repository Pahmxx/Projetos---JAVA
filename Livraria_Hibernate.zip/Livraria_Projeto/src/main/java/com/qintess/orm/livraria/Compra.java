package com.qintess.orm.livraria;

import java.util.Locale;
import java.util.Scanner;

import com.qintess.orm.livraria.dao.AutoresDao;
import com.qintess.orm.livraria.dao.EdicaoDao;
import com.qintess.orm.livraria.dao.EditorasDao;
import com.qintess.orm.livraria.dao.EnderecoDao;
import com.qintess.orm.livraria.dao.EstoqueDao;
import com.qintess.orm.livraria.dao.LivrosDao;
import com.qintess.orm.livraria.entidades.Autores;
import com.qintess.orm.livraria.entidades.Edicao;
import com.qintess.orm.livraria.entidades.Editoras;
import com.qintess.orm.livraria.entidades.Endereco;
import com.qintess.orm.livraria.entidades.Estoque;
import com.qintess.orm.livraria.entidades.Livros;

public class Compra {

	public void compra( ) {

		Autores autores = new Autores();
		Edicao edicao = new Edicao();
		Editoras editoras = new Editoras();
		Endereco endereco1 = new Endereco();
		Endereco endereco2 = new Endereco();
		Livros livros = new Livros();
		Estoque estoque = new Estoque();

		AutoresDao autoresDao = new AutoresDao();
		EdicaoDao edicaoDao = new EdicaoDao();
		EditorasDao editorasDao = new EditorasDao();
		EnderecoDao enderecoDao = new EnderecoDao();
		LivrosDao livrosDao = new LivrosDao();
		EstoqueDao estoqueDao = new EstoqueDao();

		Scanner input = new Scanner(System.in); input.useLocale(Locale.US);

		try {

			Scanner sc = new Scanner(System.in);

			System.out.println("Deseja inserir: \r\n"
					+ "1 = Livro \r\n" // AUTOR E AUTOR ENDERECO - EDICAO - EDITORA E EDITORA ENDERECO - QUANTIDADE 
					+ "2 = Autor \r\n" // ENDERECO
					+ "3 = Editora \r\n" // ENDERECO
					);

			int escolha = sc.nextInt();

			if (escolha == 1) {

				//				livrosDao.buscaEdicao().forEach(System.out::println);

				System.out.println("Edicão nova (1) ou já existente (2)?");
				int escolhaLivro = sc.nextInt();

				if(escolhaLivro == 1) {
					System.out.println("Nome do autor: ");
					String nome_autor = sc.next();
					autores.setNome_autores(nome_autor);

					System.out.println("Data a de nascimento do autor: ");
					String dataNascimento = sc.next();
					autores.setData_Nascimento(dataNascimento);

					System.out.println("Biografia do autor: ");
					String biografia = sc.next();
					autores.setBiografia(biografia);

					System.out.println("Nacionalidade do autor: ");
					String nacionalidade = sc.next();
					autores.setNacionalidade(nacionalidade);

					System.out.println("Cidade do autor: ");
					String cidade = sc.next();
					endereco1.setCidade(cidade);

					System.out.println("Rua em que reside o autor:");
					String rua = sc.next();
					endereco1.setRua(rua);
					sc.next();

					System.out.println("Número da casa do autor: ");
					int numero = sc.nextInt();
					endereco1.setNumero(numero);

					enderecoDao.insere(endereco1);
					autores.setEndereco(endereco1);
					autoresDao.insere(autores);

					System.out.println("Digite o nome do livro: ");
					String nome_livro = sc.next();
					livros.setNome_livro(nome_livro);

					System.out.println("Digite o idioma do livro: ");
					String idioma = sc.next();
					livros.setIdioma(idioma);

					System.out.println("Digite o ano de lançamento do livro: ");
					int ano = sc.nextInt();
					livros.setAno(ano);
					livros.getAutores().add(autores);

					System.out.println("Digite o nome da editora: ");
					String editora = sc.next();
					editoras.setNome(editora);

					System.out.println("Digite o telefone da editora: ");
					String telefone = sc.next();
					editoras.setTelefone(telefone);

					System.out.println("Digite a cidade da editora: ");
					String cidade_editora = sc.next();
					sc.next();
					endereco2.setCidade(cidade_editora);

					System.out.println("Digite a rua da editora: ");
					String rua_editora = sc.next();
					endereco2.setRua(rua_editora);

					System.out.println("Digite o número da editora: ");
					int numero_editora = sc.nextInt();
					endereco2.setNumero(numero_editora);

					enderecoDao.insere(endereco2);
					editoras.setEndereco(endereco2);
					editorasDao.insere(editoras);

					livros.setEditoras(editoras);
					livrosDao.insere(livros);

					System.out.println("ISBN:");
					int isbn = sc.nextInt();
					edicao.setIsbn(isbn);

					System.out.println("Digite o preço do livro: ");
					double preco = Double.parseDouble(input.nextLine());
					edicao.setPreco(preco);

					System.out.println("Digite o ano de lançamento da edição: ");
					int ano_edicao = sc.nextInt();
					edicao.setAno(ano_edicao);

					System.out.println("Digite a quantidade de páginas: ");
					int pag = sc.nextInt();
					edicao.setPag(pag);

					System.out.println("Digite a quantidade de livros: ");
					int quantidade_estoque = sc.nextInt();
					estoque.setQuantidade_estoque(quantidade_estoque);
					estoqueDao.insere(estoque);

					edicao.setEstoque(estoque);
					edicao.setEditoras(editoras);
					edicao.setLivros(livros);
					edicaoDao.insere(edicao);

				} if (escolhaLivro == 2) {
					System.out.println("Digite o ID_estoque do livro a ser inserido: ");
					int isbn = sc.nextInt();

					System.out.println("Digite a quantidade a ser inserida: ");
					int quant = sc.nextInt();
					estoque.setId_estoque(isbn);
					int quantidade = estoque.getQuantidade_estoque() + quant;
					estoque.setQuantidade_estoque(quantidade);
					estoqueDao.altera(estoque);
				}

			} if (escolha == 2 ) {
				System.out.println("Nome do autor: ");
				String nome_autor = sc.next();
				sc.next();
				autores.setNome_autores(nome_autor);

				if(!editorasDao.buscaPorNome(nome_autor).equals(null)) {
					System.out.println("Autor já cadastrado.");

				} else {

					System.out.println("Data a de nascimento do autor: ");
					String dataNascimento = sc.next();
					autores.setData_Nascimento(dataNascimento);

					System.out.println("Biografia do autor: ");
					String biografia = sc.next();
					autores.setBiografia(biografia);

					System.out.println("Nacionalidade do autor: ");
					String nacionalidade = sc.next();
					autores.setNacionalidade(nacionalidade);

					System.out.println("Cidade do autor: ");
					String cidade = sc.next();
					endereco1.setCidade(cidade);

					System.out.println("Rua em que reside o autor:");
					String rua = sc.next();
					endereco1.setRua(rua);

					System.out.println("Número da casa do autor: ");
					int numero = sc.nextInt();
					endereco1.setNumero(numero);

					enderecoDao.insere(endereco1);
					autores.setEndereco(endereco1);
					autoresDao.insere(autores);
				}

			}	if (escolha == 3 ) {

				System.out.println("Digite o nome da editora: ");
				String editora = sc.next();
				editoras.setNome(editora);

				if(!editorasDao.buscaPorNome(editora).equals(null)) {
					System.out.println("Editora já cadastrada.");

				} else {
					System.out.println("Digite o telefone da editora: ");
					String telefone = sc.next();
					editoras.setTelefone(telefone);

					System.out.println("Digite a cidade da editora: ");
					String cidade_editora = sc.next();
					endereco2.setCidade(cidade_editora);
					sc.nextLine();

					System.out.println("Digite a rua da editora: ");
					String rua_editora = sc.next();
					endereco2.setRua(rua_editora);

					System.out.println("Digite o número da editora: ");
					int numero_editora = sc.nextInt();
					endereco2.setNumero(numero_editora);

					enderecoDao.insere(endereco2);
					editoras.setEndereco(endereco2);
					editorasDao.insere(editoras);
				}


			}

		} catch (Exception e) {
			e.printStackTrace();

		}
	}
}
