package com.qintess.orm.livraria.entidades;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Estoque {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_estoque;
	
	@OneToMany
	private List <Edicao> edicao = new ArrayList <Edicao>();
	
	private int quantidade_estoque;
	
	public int getId_estoque() {
		return id_estoque;
	}
	public void setId_estoque(int id_estoque) {
		this.id_estoque = id_estoque;
	}
	
	public int getQuantidade_estoque() {
		return quantidade_estoque;
	}
	public void setQuantidade_estoque(int quantidade_estoque) {
		this.quantidade_estoque = quantidade_estoque;
	}
	
	@Override
	public String toString() {
		return "Estoque [id_estoque=" + id_estoque + ", edicao=" + edicao + ", quantidade_estoque=" + quantidade_estoque
				+ "]";
	}
	
}
