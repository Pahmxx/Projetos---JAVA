package com.qintess.orm.livraria;

import java.util.Scanner;

import com.qintess.orm.livraria.dao.EstoqueDao;
import com.qintess.orm.livraria.entidades.Estoque;

public class Venda {


	public void venda( ) {

		Estoque estoque = new Estoque();
		EstoqueDao daoEstoque = new EstoqueDao();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Deseja vender: \r\n"
				+ "1 = Livro \r\n" // AUTOR E AUTOR ENDERECO - EDICAO - EDITORA E EDITORA ENDERECO - QUANTIDADE 
				);

		int escolha = sc.nextInt();

		if (escolha == 1) {
			
			System.out.println("Digite o ID_estoque do livro a ser vendido: ");
			int id_estoque = sc.nextInt();
			
			System.out.println("Digite a quantidade a ser vendida: ");
			int quant = sc.nextInt();
			estoque.setId_estoque(id_estoque);
			daoEstoque.alteraQuantSub(id_estoque, quant);
			
			
		}
	}
}