package com.qintess.orm.livraria.entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Autores {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_autores;
	
	@Column(length = 45)
	private String nome_autores;
	
	private String data_Nascimento;
	
	@Column(length = 20)
	private String nacionalidade;

	private String biografia;
	
	@OneToOne
	private Endereco endereco;
	
	public int getId_autores() {
		return id_autores;
	}

	public void setId_autores(int id_autores) {
		this.id_autores = id_autores;
	}

	public String getNome_autores() {
		return nome_autores;
	}

	public void setNome_autores(String nome_autores) {
		this.nome_autores = nome_autores;
	}

	public String getData_Nascimento() {
		return data_Nascimento;
	}

	public void setData_Nascimento(String data_Nascimento) {
		this.data_Nascimento = data_Nascimento;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}

	public String getBiografia() {
		return biografia;
	}

	public void setBiografia(String biografia) {
		this.biografia = biografia;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	@Override
	public String toString() {
		return "Autores [id_autores=" + id_autores + ", nome_autores=" + nome_autores + ", data_Nascimento="
				+ data_Nascimento + ", nacionalidade=" + nacionalidade + ", biografia=" + biografia + ", endereco="
				+ endereco + "]";
	}

}