package com.docket.controllers;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.docket.cartorio.dto.CartorioDTO;
import com.docket.cartorio.models.Cartorio;
import com.docket.cartorio.service.CartorioService;
import com.docket.repository.CartorioRepository;

@Controller
@RequestMapping("/cartorio")
public class CartorioController {

	@Autowired	
	private CartorioRepository cartorioRepository;
	
	@Autowired	
	private CartorioService cartorioService;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		List<Cartorio> listCartorio = cartorioService.listAll();
		model.addAttribute("listCartorio", listCartorio);
		
		return "index";
	}
	
	
	@GetMapping("/novo")
	public String novo(Model model) {
		Cartorio cartorio = new Cartorio();
		model.addAttribute("cartorios", cartorio);
		return "cartorio/novo";
	}
	
	
	// CADASTRO CARTÓRIO
	
//	@PostMapping("/cadastra" )
//	public String cadastra(@Valid Cartorio cartorio, BindingResult result, Model model) {
//
//		try {
//			
//			if (result.hasErrors()) {
//				return "Cadastro Finalizado!";
//			}
//			
//			cartorioRepository.save(cartorio);
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//
//		} 
//		
//		return "redirect:/";
//
//	}	
	
	// CADASTRO CARTÓRIO
	
	@RequestMapping(value = "/cadastra", method = RequestMethod.POST)
	public String cadastra(@ModelAttribute("cartorio") Cartorio cartorio) {
		cartorioService.save(cartorio);
		
		return "redirect:/";
	}
	
	
	
	// LISTA CARTÓRIO
	
	@GetMapping("/list")
	private List <CartorioDTO> retornaCartorioDto() {
		var cartoriolDto = new ArrayList<CartorioDTO>();
		cartorioRepository.findAll().forEach(c -> {
			cartoriolDto.add(new CartorioDTO(c));
		
		});
		
		return cartoriolDto;
	}
	
	
	// DELETA CARTÓRIO
	
	@GetMapping("/deleta/{id}")
	public Cartorio deleta(@PathVariable int id) {
		Optional<Cartorio> cartorio = cartorioRepository.findById(id);

		try {
			if(!cartorio.equals(null)) {			
				cartorioRepository.deleteById(id);
			} 
			
		} catch (NullPointerException e) {
			System.err.println("Cartório com o ID: " + id + " nao encontrado!");
			e.printStackTrace();

		} catch (InputMismatchException i) {
			System.err.println("Digite somente numeros!");
			i.printStackTrace();
		}

		return cartorio.get();
	}
	
	
	// EDITA CARTÓRIO
	
	@GetMapping("/edita/{id}")
	public String edita(@PathVariable int id, Model model) {

		var cartoriolOptional = cartorioRepository.findById(id);

		try {
			if(cartoriolOptional.isPresent()) {
				var cartorio = cartoriolOptional.get();
				var cartorioDto = new CartorioDTO(cartorio);
				model.addAttribute("cartorio", cartorioDto);
			}
			
		} catch (NullPointerException e) {
			System.err.println("Cartório com o ID: " + id + " nao encontrado!");
			e.printStackTrace();

		} catch (InputMismatchException i) {
			System.err.println("Digite somente numeros!");
			i.printStackTrace();
		}

		return "cartorio/novo";
	}
	
	// BUSCA POR ID
	
	public Optional<Cartorio> buscaCartorioByID(Integer id) {
		Optional<Cartorio> cartorio = cartorioRepository.findById(id);
		
		if(cartorio.equals(null)) {
		System.out.println("Cartorio com o ID: " + id + " nao encontrado!");
		
		}
		
		return cartorio;
			
	}
}
