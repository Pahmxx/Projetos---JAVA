package com.docket.cartorio.dto;

import com.docket.cartorio.models.Endereco;

public class EnderecoDTO {
	
	private int id;
	private String cep;
	private String ruaCartorio;
	private String numCartorio;
	private String bairroCartorio;
	private String cidade;
	private String estado;
	
	public EnderecoDTO() {
	}

	public EnderecoDTO(Endereco e) {
		this.id = e.getId();
		this.cep = e.getCep();
		this.ruaCartorio = e.getRuaCartorio();
		this.numCartorio = e.getNumCartorio();
		this.bairroCartorio = e.getBairroCartorio();
		this.cidade = e.getCidade();
		this.estado = e.getEstado();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getRuaCartorio() {
		return ruaCartorio;
	}

	public void setRuaCartorio(String ruaCartorio) {
		this.ruaCartorio = ruaCartorio;
	}

	public String getNumCartorio() {
		return numCartorio;
	}

	public void setNumCartorio(String numCartorio) {
		this.numCartorio = numCartorio;
	}

	public String getBairroCartorio() {
		return bairroCartorio;
	}

	public void setBairroCartorio(String bairroCartorio) {
		this.bairroCartorio = bairroCartorio;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public Endereco conveter() {
		return new Endereco(this.id, this.cep, this.ruaCartorio, this.numCartorio, this.bairroCartorio, this.cidade, this.estado);
	}

}
