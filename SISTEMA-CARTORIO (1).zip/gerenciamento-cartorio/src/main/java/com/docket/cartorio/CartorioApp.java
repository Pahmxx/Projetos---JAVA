package com.docket.cartorio;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.docket.cartorio.dto.CartorioDTO;
import com.docket.cartorio.models.Cartorio;
import com.docket.cartorio.models.Certidao;
import com.docket.cartorio.models.Contato;
import com.docket.cartorio.models.Endereco;
import com.docket.controllers.CartorioController;
import com.docket.repository.CartorioRepository;

public class CartorioApp {

	public static void main( String[] args ) throws ParseException

	{

		CartorioController cartorioController = new CartorioController();
		
		Cartorio cartorio = new Cartorio();
		Endereco endereco = new Endereco();
		Contato contato = new Contato();
		Certidao certidao = new Certidao();
		
		CartorioRepository cartorioRepository;
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Digite a operação desejada");
		System.out.println ("Insere Cartório = 1 \r\n"
				+ "Deleta Cartório = 2 \r\n"
				+ "Lista Cartório  = 3 \r\n"
				+ "Buscar Cartório = 4 \r\n");

		int escolha = sc.nextInt();

		if (escolha == 1) {
			System.out.println("Dados - Cartório | Digite o nome do cartório: ");
			String nome = sc.next();
			cartorio.setNomeCartorio(nome);
			
			System.out.println("Dados - Cartório | Digite a data do cadastro: ");
			String data = sc.next();
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date date = formatter.parse(data);
			cartorio.setDataCadastro(date);
			
			System.out.println("Endereço - Cartório | Digite o CEP: ");
			String cep = sc.next();
			endereco.setCep(cep);
			
			System.out.println("Endereço - Cartório | Digite a rua: ");
			String rua = sc.next();
			endereco.setRuaCartorio(rua);
			
			System.out.println("Endereço - Cartório | Digite o número: ");
			String numero = sc.next();
			endereco.setNumCartorio(numero);
			sc.nextLine();
			
			System.out.println("Endereço - Cartório | Digite o bairro: ");
			String bairro = sc.next();
			endereco.setBairroCartorio(bairro);
			
			System.out.println("Endereço - Cartório | Digite a cidade: ");
			String cidade = sc.next();
			endereco.setCidade(cidade);
			
			System.out.println("Endereço - Cartório | Digite o estado: ");
			String estado = sc.next();
			endereco.setEstado(estado);
			
			cartorio.setEndereco(endereco);
			
			
			System.out.println("Contato - Cartório | Digite o número de contato");
			String numeroCont = sc.next();
			contato.setNumContato(numeroCont);
			
			System.out.println("Serviços - Cartório | Digite o tipo da(das) certidões disponíveis");
			String tipoCertidao = sc.next();
			certidao.setTipoCertidao(tipoCertidao);
			
			System.out.println("Serviços - Cartório | Digite o nome da(das) certidões disponíveis");
			String nomeCertidao = sc.next();
			certidao.setNomeCertidao(nomeCertidao);
			
			System.out.println("Serviços - Cartório | Digite o tempo de entrega da(das) certidões disponíveis");
			String tempoCertidao = sc.next();
			certidao.setTempoEntrega(tempoCertidao);
			
			
		} if (escolha == 2 ) {
			System.out.println("Informe o id do cartório a ser deletado");
			int id = sc.nextInt();
			cartorioController.deleta(id);

		} if (escolha == 3) {


		} if (escolha == 4) {
			System.out.println("Informe o id do cartório a ser buscado");
			int id = sc.nextInt();
			cartorioController.buscaCartorioByID(id);

		}
	}
}
