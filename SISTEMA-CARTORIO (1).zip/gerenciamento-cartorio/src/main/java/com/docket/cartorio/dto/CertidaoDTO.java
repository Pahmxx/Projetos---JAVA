package com.docket.cartorio.dto;

import com.docket.cartorio.models.Certidao;

public class CertidaoDTO {

	private int idCertidao;
	private String tipoCertidao;
	private String nomeCertidao;
	
	public CertidaoDTO() {
	}

	public CertidaoDTO(Certidao c) {
		this.idCertidao = c.getIdCertidao();
		this.tipoCertidao = c.getTipoCertidao();
		this.nomeCertidao = c.getNomeCertidao();
	}

	public int getIdCertidao() {
		return idCertidao;
	}

	public void setIdCertidao(int idCertidao) {
		this.idCertidao = idCertidao;
	}

	public String getTipoCertidao() {
		return tipoCertidao;
	}

	public void setTipoCertidao(String tipoCertidao) {
		this.tipoCertidao = tipoCertidao;
	}

	public String getNomeCertidao() {
		return nomeCertidao;
	}

	public void setNomeCertidao(String nomeCertidao) {
		this.nomeCertidao = nomeCertidao;
	}
	
	public Certidao conveter() {
		return new Certidao(idCertidao, this.tipoCertidao, this.nomeCertidao);
	}
	
}
