package com.docket.cartorio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartorioApplicationTests {

	@Test
	void contextLoads() {
	}

}
