package com.qintess.dvdrental.ator.entidades;

import java.sql.Date;

public class Film_Category {

	private int category_id;
	private int film_id;
	private Date last_update;

	public Film_Category(int category_id, int film_id, Date last_update) {
		super();
		this.category_id = category_id;
		this.film_id = film_id;
		this.last_update = last_update;
	}

	public Film_Category() {}

	public int getCategory_id() {
		return category_id;
	}

	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	public int getFilm_id() {
		return film_id;
	}

	public void setFilm_id(int film_id) {
		this.film_id = film_id;
	}

	public Date getLast_update() {
		return last_update;
	}

	public void setLast_update(Date last_update) {
		this.last_update = last_update;
	}

	@Override
	public String toString() {
		return "Film_Category [category_id=" + category_id + ", film_id=" + film_id + ", last_update=" + last_update
				+ "]";
	}
}