package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.entidades.Customer;
import com.qintess.dvdrental.entidades.Store;

public class StoreDao implements DaoBase<Store> {

	@Override
	public List<Store> listaTodos() {

		List<Store> list = new ArrayList<Store>();

		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);

			String sql = "SELECT store_id, manager_staff_id, address_id, last_update FROM store";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Store store = new Store();

				store.setStore_id(rs.getInt("store_id"));
				store.setManager_Staff_Id(rs.getInt("manager_staff_id"));
				store.setFulladdress(rs.getInt("address_id"));
				store.setLast_update(rs.getDate("last_update"));

				list.add(store);

			} 

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public Store buscaPorId(int id) {
		Store store = null;

		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT store_id, manager_staff_id, address_id, last_update FROM store WHERE store_id = ?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);


			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

				store = new Store();


				store.setStore_id(rs.getInt("store_id"));
				store.setManager_Staff_Id(rs.getInt("manager_staff_id"));
				store.setFulladdress(rs.getInt("address_id"));
				store.setLast_update(rs.getDate("last_update"));
			}


		} catch (SQLException e) {
			e.printStackTrace();
		}

		return store;
	}

	@Override
	public boolean delete(int id) {
		
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "DELETE FROM store WHERE customer_Id = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			int rs = pstmt.executeUpdate();
			if (rs > 0) {
				System.out.println("Store deletado!");
			}
			conn.commit();
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	@Override
	public boolean altera(Store entidade) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insere(Store entidade) {
		// TODO Auto-generated method stub
		return false;
	}



}
