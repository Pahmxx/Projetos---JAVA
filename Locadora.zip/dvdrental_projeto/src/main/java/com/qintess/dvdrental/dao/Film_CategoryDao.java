package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.ator.entidades.Category;
import com.qintess.dvdrental.ator.entidades.Film;
import com.qintess.dvdrental.ator.entidades.Film_Category;



public class Film_CategoryDao implements DaoBase<Film_Category> {

	@Override
	public List<Film_Category> listaTodos() {
		
		List<Film_Category> listFC = new ArrayList<Film_Category>();
		 
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "select  film_id, category_id, last_update from film_category";
	
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Film_Category a = new Film_Category();

				a.setCategory_id(rs.getInt("category_id"));
				a.setFilm_id(rs.getInt("film_id"));
				a.setLast_update(rs.getDate("last_update"));
				
				
				listFC.add(a);
			} 	
			
			
		} catch (SQLException e){
			e.printStackTrace();
		}
		return listFC;
	}

	@Override
	public Film_Category buscaPorId(int id) {
		
		Film_Category f = null;
		Film_Category film_cat = new Film_Category();
		Category category = new Category();
		Film film = new Film ();
		
		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT film_id, category_id, last_update FROM film_category WHERE category_id = ?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

				 f = new Film_Category();
							

				film.setFilme_id(rs.getInt("film_id"));
				category.setCategory_id(rs.getInt("category_id"));
				f.setLast_update(rs.getDate("last_update"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return f;
	}
	@Override
	public boolean delete(int id) {
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "DELETE FROM film_category WHERE category_Id = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			int rs = pstmt.executeUpdate();
			if (rs > 0) {
				System.out.println("Customer deletado!");
			}
			conn.commit();
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	@Override
	public boolean altera(Film_Category film_category) {
		return false;
		
	}

	@Override
	public boolean insere(Film_Category film_category) {
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);

			String sql = "INSERT INTO film_actor( actor_id, film_id) VALUES ( ?, ?)";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, film_category.getCategory_id());
			pstmt.setInt(2, film_category.getFilm_id());
			

			pstmt.executeUpdate();

			conn.commit();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

		return true;	
}

}
