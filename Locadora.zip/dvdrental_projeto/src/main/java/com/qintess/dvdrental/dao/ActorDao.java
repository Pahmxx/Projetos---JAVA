package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.ator.entidades.Actor;
import com.qintess.dvdrental.dao.Conexao;
import com.qintess.dvdrental.dao.DaoBase;
import com.qintess.dvdrental.entidades.Customer;


public class ActorDao implements DaoBase<Actor> {
	
	@Override
	public List<Actor> listaTodos() {

		List<Actor> list = new ArrayList<Actor>();

		try (Connection conn = Conexao.abreConexao()){	
			conn.setAutoCommit(false);

			String sql = "SELECT actor_id, first_name, last_name, last_update FROM actor";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Actor a = new Actor();

				a.setActor_id(rs.getInt("actor_id"));
				a.setFirst_name(rs.getString("first_name"));
				a.setLast_name(rs.getString("last_name"));
				a.setLast_update(rs.getDate("last_update"));		

				list.add(a);

			} 

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public boolean delete(int id) {
		return false;
	}


	@Override
	public boolean altera(Actor entidade) {
		try(Connection conn = Conexao.abreConexao()) {

			String sql = "UPDATE Actor SET first_name=?, last_name=? where actor_id=?;";

			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, entidade.getFirst_name());
			pstmt.setString(2, entidade.getLast_name());
			pstmt.setInt(3, entidade.getActor_id());

			pstmt.executeUpdate();
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean insere(Actor actor) {


		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);

			String sql = "INSERT INTO actor (first_name, last_name) VALUES (?, ?)";

			PreparedStatement pstmt = conn.prepareStatement(sql);


			pstmt.setString(1, actor.getFirst_name());
			pstmt.setString(2, actor.getLast_name());

			pstmt.executeUpdate();

			conn.commit();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	@Override
	public Actor buscaPorId(int id) {
		Actor actor = null;

		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT actor_id, first_name, last_name, last_update FROM actor WHERE actor_id=?";



			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

				actor = new Actor();

				actor.setActor_id(rs.getInt("actor_id"));
				actor.setFirst_name(rs.getString("first_name"));
				actor.setLast_name(rs.getString("last_name"));
				actor.setLast_update(rs.getDate("last_update"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return actor;
	}
	
	public Actor actorInserido (Actor actor) {
		Actor ac = null;

		try(Connection conn = Conexao.abreConexao()) {
			String sqlUP = "SELECT * FROM actor WHERE actor_id = (SELECT MAX(ACTOR_ID) FROM ACTOR)";

			PreparedStatement pt = conn.prepareStatement(sqlUP);

			ResultSet rs = pt.executeQuery();

			while(rs.next()) {

				ac = new Actor();

				ac.setActor_id(rs.getInt("actor_id"));
				ac.setFirst_name(rs.getString("first_name"));
				ac.setLast_name(rs.getString("last_name"));
				ac.setLast_update(rs.getDate("last_update"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return ac;
	}
}