package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.entidades.Country;
import com.qintess.dvdrental.entidades.Customer;

public class CountryDao implements DaoBase<Country> {

	@Override
	public List<Country> listaTodos() {
		
		List<Country> list = new ArrayList<Country>();
		 
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "SELECT country_id, country, last_update FROM country";
		
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
			Country c = new Country();
			
			c.setCountry_id(rs.getInt("country_id"));
			c.setCountry(rs.getString("country"));
			c.setLast_update(rs.getDate("last_update"));		

			list.add(c);
			
			} 
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public boolean delete(int id) {
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "DELETE FROM country WHERE country_id = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			
			int rs = pstmt.executeUpdate();
			if (rs > 0) {
				System.out.println("Country deletado!");
			}
			conn.commit();
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}


	@Override
	public boolean altera(Country entidade) {
		try(Connection conn = Conexao.abreConexao()) {

			String sql = "UPDATE country SET country=? where country_id=?;";

			PreparedStatement pstmt = conn.prepareStatement(sql);
						
			pstmt.setString(1, entidade.getCountry());
			pstmt.setInt(2, entidade.getCountry_id());
			
			
			pstmt.executeUpdate();
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean insere(Country country) {

		//Country country = null;
		
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "INSERT INTO country( "
					+ "country)"
					+ "VALUES (?)";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			
			
			pstmt.setString(1, country.getCountry());
			
			pstmt.executeUpdate();
			
			conn.commit();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}


	@Override
	public Country buscaPorId(int id) {
		Country country = null;

		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT country_id, country, last_update FROM country WHERE country_id = ?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

				country = new Country();

				country.setCountry_id(rs.getInt("country_id"));
				country.setCountry(rs.getString("country"));
				country.setLast_update(rs.getDate("last_update"));
			
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return country;
	}
	
	public Country countryInserido (Country coun) {

		try(Connection conn = Conexao.abreConexao()) {
			String sqlUP = "SELECT * FROM country WHERE country_id = (SELECT MAX(COUNTRY_ID) FROM COUNTRY)";

			PreparedStatement pt = conn.prepareStatement(sqlUP);

			ResultSet rs = pt.executeQuery();

			while(rs.next()) {


				coun.setCountry_id(rs.getInt("country_id"));
				coun.setCountry(rs.getString("country"));
				coun.setLast_update(rs.getDate("last_update"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return coun;
	}
}
