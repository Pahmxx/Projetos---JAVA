package com.qintess.dvdrental.entidades;

import java.sql.Date;

public class Store {
	
	private int store_id;
	private int manager_Staff_Id;
	private int fulladdress;
	private Date last_update;
	
	public Store () {}
	
	public Store(int store_id, int fulladdress, int manager_Staff_Id, Date last_update) {
		this.store_id = store_id;
		this.fulladdress = fulladdress;
		this.manager_Staff_Id = manager_Staff_Id;
		this.last_update = last_update;
	}
	public int getId() {
		return store_id;
	}
	public void setId(int id) {
		this.store_id = id;
	}
	public int getManager_Staff_Id() {
		return manager_Staff_Id;
	}
	public void setManager_Staff_Id(int manager_Staff_Id) {
		this.manager_Staff_Id = manager_Staff_Id;
	}
	public int getFulladdress() {
		return fulladdress;
	}
	public void setFulladdress(int fulladdress) {
		this.fulladdress = fulladdress;
	}	
	
	
	public int getStore_id() {
		return store_id;
	}

	public void setStore_id(int store_id) {
		this.store_id = store_id;
	}
	

	public Date getLast_update() {
		return last_update;
	}

	public void setLast_update(Date last_update) {
		this.last_update = last_update;
	}

	@Override
	public String toString() {
		return "Store [store_id=" + store_id + ", manager_Staff_Id=" + manager_Staff_Id + ", fulladdress=" + fulladdress
				+ ", last_update=" + last_update + "]";
	}


	
}