package com.qintess.dvdrental;

import java.util.List;
import java.util.Scanner;

import com.qintess.dvdrental.dao.CityDao;
import com.qintess.dvdrental.dao.CountryDao;
import com.qintess.dvdrental.dao.CustomerDao;
import com.qintess.dvdrental.dao.FullAddressDao;
import com.qintess.dvdrental.dao.PaymentDao;
import com.qintess.dvdrental.dao.RentalDao;
import com.qintess.dvdrental.dao.StaffDao;
import com.qintess.dvdrental.dao.StoreDao;
import com.qintess.dvdrental.entidades.Payment;

public class BuscarPorId {


	public void buscarPorId( ) {
		
		FullAddressDao daoFull = new FullAddressDao();
		CountryDao daoCountry = new CountryDao();
		CityDao daoCity = new CityDao();
		CustomerDao daoCust = new CustomerDao(null);
		StoreDao daoStore = new StoreDao();
		StaffDao daoStaff = new StaffDao();
		RentalDao daoRental = new RentalDao();
		PaymentDao daoPayment = new PaymentDao();

		Scanner sc = new Scanner(System.in);
		System.out.println("Deseja buscar: \r\n"
				+ "1 = Customer \r\n"
				+ "2 = Address \r\n"
				+ "3 = Country \r\n"
				+ "4 = City \r\n"
				+ "5 = Staff \r\n"
				+ "6 = Store \r\n"
				+ "7 = Rental \r\n"
				+ "8 = Payment \r\n"
				);

		int escolha = sc.nextInt();

		if (escolha == 1 ) {
			System.out.print("Digite o ID a ser buscado: ");
			int id = sc.nextInt();
			System.out.println(daoCust.buscaPorId(id));

		} if (escolha == 2) {
			System.out.print("Digite o ID a ser buscado: ");
			int id = sc.nextInt();
			System.out.println(daoFull.buscaPorId(id));

		} if (escolha == 3) {

			System.out.print("Digite o ID a ser buscado: ");
			int id = sc.nextInt();
			System.out.println(daoCountry.buscaPorId(id));

		} if(escolha == 4) {
			System.out.print("Digite o ID a ser buscado: ");
			int id = sc.nextInt();
			System.out.println(daoCity.buscaPorId(id));

		} if (escolha == 5) {
			System.out.print("Digite o ID a ser buscado: ");
			int id = sc.nextInt();
			System.out.println(daoStaff.buscaPorId(id));

		} if (escolha == 6 ) {
			System.out.print("Digite o ID a ser buscado: ");
			int id = sc.nextInt();
			System.out.println(daoStore.buscaPorId(id));

		} if (escolha == 7 ) {
			System.out.print("Digite o ID a ser buscado: ");
			int id = sc.nextInt();
			System.out.println(daoRental.buscaPorId(id));

		} if (escolha == 8) {
			System.out.print("Digite o ID do cliente a ser buscado o histórico de pagamento: ");
			int id = sc.nextInt();
			
			List<Payment> paymentRetornado = daoPayment.buscarPorId(id);
			System.out.println(paymentRetornado);	
			
		}

	} 
}