package com.qintess.dvdrental;

import java.util.Scanner;

import com.qintess.dvdrental.ator.entidades.Actor;
import com.qintess.dvdrental.ator.entidades.Category;
import com.qintess.dvdrental.ator.entidades.Film;
import com.qintess.dvdrental.ator.entidades.Film_Category;
import com.qintess.dvdrental.dao.ActorDao;
import com.qintess.dvdrental.dao.CategoryDao;
import com.qintess.dvdrental.dao.FilmDao;
import com.qintess.dvdrental.dao.Film_CategoryDao;


public class List_Film {
public void list_film( ) {
		
		FilmDao daoFilm = new FilmDao();
		CategoryDao daoCategory = new CategoryDao();
		ActorDao daoActor = new ActorDao();
		Film_CategoryDao daoFilmC = new Film_CategoryDao();
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Deseja listar: \r\n"
				+ "1 = Film \r\n"
				+ "2 = Categoria \r\n"
				+ "3 = Ator \r\n"
				+ "4 = Film_Category"
				);

		int escolha = sc.nextInt();

		System.out.println("===== LIST ===== ");

		if (escolha == 1) {
			for(Film filme : daoFilm.listaTodos()){
				
				System.out.println(filme.getFilme_id() + " | " + filme.getTitle() + " | " + 
						filme.getDescription() + " | " + filme.getRelease_year()  + " | " + 
						filme.getLanguage_id()  + " | " + filme.getRental_duration() + " | " +
						filme.getRental_rate() + " | " + filme.getLenght() + " | " + filme.getReplacement_cost()  + " | " +
						filme.getRating() + " | " + filme.getLast_updade()  + " | " + filme.getSpecial_features()  + " | " +
						filme.getFulltext());
			}
			
		} if (escolha == 2) {
			for(Category cate : daoCategory.listaTodos()){

				System.out.println(cate.getCategory_id() + " | " + cate.getName() + " | " + 
						cate.getLast_update());
			}	
			
		} if (escolha == 3) {
			for(Actor ac : daoActor.listaTodos()){

				System.out.println(ac.getActor_id() + " | " + ac.getFirst_name() + " | " + 
						ac.getFirst_name() + " | " + ac.getLast_update());
			}	
			
		} if (escolha == 4) {
			for(Film_Category f : daoFilmC.listaTodos()){

				System.out.println(f.getFilm_id() + " | " + f.getCategory_id() + " | " + f.getLast_update());
			}	
		}
		}
}
