package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.ator.entidades.Category;
import com.qintess.dvdrental.entidades.Customer;

public class CategoryDao implements DaoBase<Category> {
	@Override
	public List<Category> listaTodos() {
		
		List<Category> list = new ArrayList<Category>();
		 
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "SELECT category_id, name, last_update FROM category";
		
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
			Category cat = new Category();
			
			cat.setCategory_id(rs.getInt("category_id"));
			cat.setName(rs.getString("name"));
			cat.setLast_update(rs.getDate("last_update"));
			

			list.add(cat);
			
			} 
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public boolean delete(int id) {
			return false;
	}


	@Override
	public boolean altera(Category entidade) {
		try(Connection conn = Conexao.abreConexao()) {

			String sql = "UPDATE category SET name=? where category_id=?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, entidade.getName());
			pstmt.setInt(2, entidade.getCategory_id());

			pstmt.executeUpdate();
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean insere(Category category) {

		
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "INSERT INTO category( "
					+ "name)"
					+ "VALUES (?)";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			
			pstmt.setString(1, category.getName());
			
			pstmt.executeUpdate();
			
			conn.commit();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}


	@Override
	public Category buscaPorId(int id) {
		Category category = null;

		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT category_id, name, last_update FROM category WHERE category_id=?";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

				category = new Category();

				category.setCategory_id(rs.getInt("category_id"));
				category.setName(rs.getString("name"));
				category.setLast_update(rs.getDate("last_update"));
			
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return category;
	}
	
	public Category categoryInserido (Category category) {
		
		Category cat = null;

		try(Connection conn = Conexao.abreConexao()) {
			String sqlUP = "SELECT * FROM category WHERE category_id = (SELECT MAX(CATEGORY_ID) FROM CATEGORY)";

			PreparedStatement pt = conn.prepareStatement(sqlUP);

			ResultSet rs = pt.executeQuery();

			while(rs.next()) {

				cat = new Category();
				
				cat.setCategory_id(rs.getInt("category_id"));
				cat.setName(rs.getString("name"));
				cat.setLast_update(rs.getDate("last_update"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cat;
	}
}