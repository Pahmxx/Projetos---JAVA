package com.qintess.dvdrental.entidades;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.directory.InvalidAttributesException;

public class Customer {

	private int customerId;
	private int storeId;
	private int addressId;
	private String firstName;
	private String lastName;
	private String email;
	private String status;
	private int active;
	private boolean Activebool;
	private Date CreateDate;
	private Date LastUpdate;
	private FullAddress fullAddress;
	private Store store;

	public Customer() {}

	public Customer(int customerId, int storeId, String firstName, String lastName, String email) {
		this.customerId = customerId;
		this.storeId = storeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	
	}
	
	public Customer(ResultSet rs) throws SQLException {
		
		this.customerId = rs.getInt("customer_id");
		this.firstName = rs.getString("first_name");
		this.lastName = rs.getString("last_name");
		this.email = rs.getString("email");
		
	}
	
	public void preencherCustomer(ResultSet rs) throws SQLException {
		this.customerId = rs.getInt("customer_id");
		this.firstName = rs.getString("first_name");
		this.lastName = rs.getString("last_name");
		this.email = rs.getString("email");
		
	}
	
	public String formataEndereco() throws InvalidAttributesException {
		
		if(fullAddress == null)
			throw new InvalidAttributesException("FullAddress está nulo");
		
		return "Endereço: " + fullAddress.getAddress() + ", " 
					+ fullAddress.getPostalCode() 
					+ " - " + fullAddress.getCityId() 
					+ " - " + fullAddress.getCountry()
					+ ".";
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status.equals("1") ? "Ativo" : "Inativo"; 
	}

	public int getActive() {
		return active;
	}
	
	public void setActive(int active) {
		this.active = active;
	}
	
	public FullAddress getFullAddress() {
		return fullAddress;
	}

	public void setFullAddress(FullAddress fullAddress) {
		this.fullAddress = fullAddress;
	}

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public int getStoreId() {
		return storeId;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	

	public boolean isActivebool() {
		return Activebool;
	}

	public void setActivebool(boolean activebool) {
		Activebool = activebool;
	}

	public Date getCreateDate() {
		return CreateDate;
	}

	public void setCreateDate(Date date) {
		CreateDate = date;
	}

	public Date getLastUpdate() {
		return LastUpdate;
	}

	public void setLastUpdate(Date date) {
		LastUpdate = date;
	}

	@Override
	public String toString() {
		return "CustomerID: " + customerId + " | " + "FirstName: " + firstName + " | " + "LastName: " + lastName + " | " + "Email: "
				+ email + " | " + "Active: " + active + ".";
	}
	
	
}
