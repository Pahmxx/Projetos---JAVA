package com.qintess.dvdrental;

import java.util.Scanner;

import com.qintess.dvdrental.ator.entidades.Actor;
import com.qintess.dvdrental.ator.entidades.Category;
import com.qintess.dvdrental.ator.entidades.Film;
import com.qintess.dvdrental.dao.ActorDao;
import com.qintess.dvdrental.dao.CategoryDao;
import com.qintess.dvdrental.dao.FilmDao;


public class Update_Film {
	public void update_Film( ) {

		FilmDao daoFilm = new FilmDao ();
		CategoryDao daoCategory = new CategoryDao();
		ActorDao daoActor = new ActorDao();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Deseja atualizar: \r\n"
				+ "1 = Categoria \r\n"
				+ "2 = Filme \r\n"
				+ "3 = Ator \r\n"
				);

		int escolha = sc.nextInt();

		System.out.println();
		System.out.println("===== UPDATE =======");

		if (escolha == 1) {
			
			Category category = new Category();
			System.out.print("Digite o ID da categoria a ser atualizada: ");
			int idU = sc.nextInt();
			category.setCategory_id(idU);
			
			System.out.print("Digite o novo nome: ");
			String nome = sc.next();
			category.setName(nome);
			
			if(daoCategory.altera(category)){
				System.out.println();
//				System.out.println("Novos dados:");
//				System.out.println(daoFilm.altera(filme));
				System.out.println("Dados Alterados com sucesso!");
			}

		} if (escolha == 2) {

			Film filme = new Film();
			System.out.print("Digite o ID do filme a ser atualizado: ");
			int idU = sc.nextInt();
			filme.setFilme_id(idU);
			sc.nextLine();

			System.out.print("Digite o novo Filme: ");
			String filUpp = sc.next();
			sc.nextLine();
			filme.setTitle(filUpp);

			System.out.print("Digite a nova Descrição: ");
			String descUpp = sc.next();
			sc.nextLine();
			filme.setDescription(descUpp);

			System.out.print("Digite o ano de lançamento: ");
			int relYerUpp = sc.nextInt();
			sc.nextLine();
			filme.setRelease_year(relYerUpp);

			System.out.print("Digite qual a duração do aluguel: ");
			Double renDurUpp = sc.nextDouble();
			sc.nextLine();
			filme.setRental_duration(renDurUpp);

			System.out.print("Digite qual a taxa do aluguel: ");
			Double renRatUpp = sc.nextDouble();
			sc.nextLine();
			filme.setRental_rate(renRatUpp);

			System.out.print("Digite qual o comprimento: ");
			Double lenUpp = sc.nextDouble();
			sc.nextLine();
			filme.setLenght(lenUpp);

			System.out.print("Digite qual o custo de reposição: ");
			Double repCostUpp = sc.nextDouble();
			sc.nextLine();
			filme.setReplacement_cost(repCostUpp);

			System.out.print("Digite a Avaliação: ");
			String ratUpp = sc.next();
			sc.nextLine();
			filme.setRating(ratUpp);

			System.out.print("Digite a características especiais: ");
			String specFeatUpp = sc.next();
			sc.nextLine();
			filme.setSpecial_features(specFeatUpp);

			System.out.print("Digite o texto completo: ");
			String fullTextUpp = sc.next();
			sc.nextLine();
			filme.setFulltext(fullTextUpp);

			if(daoFilm.altera(filme)){
				System.out.println();
				System.out.println("Novos dados:");
				System.out.println(daoFilm.altera(filme));
				System.out.println("Dados Alterados com sucesso!");
			}
			
		} if (escolha == 3) {
			
			Actor ac = new Actor();
			System.out.print("Digite o ID do ator a ser atualizado: ");
			int idU = sc.nextInt();
			ac.setActor_id(idU);
			sc.nextLine();

			System.out.print("Digite novo nome: ");
			String nomeUp = sc.nextLine();
			ac.setFirst_name(nomeUp);

			System.out.print("Digite o novo sobrenome: ");
			String sobrenomeUp = sc.nextLine();
			ac.setLast_name(sobrenomeUp);

			if(daoActor.altera(ac)){
				System.out.println();
//				System.out.println("Novos dados:");
//				System.out.println(daoActor.actorUpdate(ac));
				System.out.println("Dados Alterados com sucesso!");

			}else {
				System.out.println("É necessario prencher todos os campos");
			}
		} 
	}
}