package com.qintess.dvdrental;

import java.text.ParseException;
import java.util.Scanner;


public class App_Customer {

	public static void main( String[] args ) throws ParseException

	{

		Scanner sc = new Scanner(System.in);

		List list = new List();
		Insert insert = new Insert();
		Update update = new Update ();
		
		
		BuscarPorId buscarPorId = new BuscarPorId();
		Delete delete = new Delete ();
		
		System.out.println("Digite a operação desejada");
		System.out.println ("Insere = 1 \r\n"
				+ "Deleta = 2 \r\n"
				+ "Lista  = 3 \r\n"
				+ "Update = 4 \r\n"
				+ "Buscar = 5 \r\n");

		int escolha = sc.nextInt();

		if (escolha == 1) {
			insert.insert();

		} if (escolha == 2 ) {
			delete.delete();
			
		} if (escolha == 3) {
			list.list();

		} if (escolha == 4) {
			update.update();

		} if (escolha == 5) {
			buscarPorId.buscarPorId();
		}
	}
}
