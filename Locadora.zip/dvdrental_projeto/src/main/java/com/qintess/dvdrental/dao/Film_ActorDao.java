package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.ator.entidades.Film_Actor;

public class Film_ActorDao implements DaoBase<Film_Actor> {
	
	@Override
	public List<Film_Actor> listaTodos() {
		
		List<Film_Actor> list = new ArrayList<Film_Actor>();
		 
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "SELECT actor_id, film_id, last_update FROM film_Actor";
		
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
			Film_Actor fActor = new Film_Actor();
			
			fActor.setActor_id(rs.getInt("actor_id"));
			fActor.setFilm_id(rs.getInt("film_id"));
			fActor.setLast_update(rs.getDate("last_update"));
			

			list.add(fActor);
			
			} 
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public boolean delete(int id) {
			return false;
	}


	@Override
	public boolean altera(Film_Actor entidade) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insere(Film_Actor actor) {

		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);

			String sql = "INSERT INTO film_actor( actor_id, film_id) VALUES ( ?, ?)";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, actor.getActor_id());
			pstmt.setInt(2, actor.getFilm_id());
			

			pstmt.executeUpdate();

			conn.commit();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

		return true;

	}


	@Override
	public Film_Actor buscaPorId(int id) {
		
		Film_Actor film_Actor = null;
		
		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT actor_id, film_id, last_update FROM film_Actor WHERE film_id=?";
			
			

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

				film_Actor = new Film_Actor();

				film_Actor.setActor_id(rs.getInt("actor_id"));
				film_Actor.setFilm_id(rs.getInt("film_id"));
				film_Actor.setLast_update(rs.getDate("last_update"));
				
			
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return film_Actor;
	}
}
