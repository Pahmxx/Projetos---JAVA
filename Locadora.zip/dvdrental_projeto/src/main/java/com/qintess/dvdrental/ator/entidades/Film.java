package com.qintess.dvdrental.ator.entidades;

import java.sql.Date;

public class Film {
	
	private int film_id;
	private String title;
	private String description;
	private int release_year;
	private int language_id;
	private double rental_duration;
	private double rental_rate;
	private double lenght;
	private double replacement_cost;
	private String rating;
	private Date last_updade;
	private String special_features;
	private String fulltext;

	public Film() {}

	public Film (int filme_id, String title, String description, int release_year, int language_id, Double rental_duration,
			Double rental_rate, Double lenght, Double replacement_cost, String rating, Date last_updade, String special_features, String fulltext) {
		
		this.film_id = filme_id;
		this.title = title;
		this.description = description;
		this.release_year = release_year;
		this.language_id = language_id;
		this.rental_duration = rental_duration;
		this.rental_rate = rental_rate;
		this.lenght = lenght;
		this.replacement_cost = replacement_cost;
		this.rating = rating;
		this.last_updade = last_updade;
		this.special_features = special_features;
		this.fulltext = fulltext;
	}	


	public int getFilme_id() {
		return film_id;
	}

	public void setFilme_id(int filme_id) {
		this.film_id = filme_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getRelease_year() {
		return release_year;
	}

	public void setRelease_year(int release_year) {
		this.release_year = release_year;
	}

	public int getLanguage_id() {
		return language_id;
	}

	public void setLanguage_id(int language_id) {
		this.language_id = language_id;
	}

	public double getRental_duration() {
		return rental_duration;
	}

	public void setRental_duration(double rental_duration) {
		this.rental_duration = rental_duration;
	}

	public double getRental_rate() {
		return rental_rate;
	}

	public void setRental_rate(double rental_rate) {
		this.rental_rate = rental_rate;
	}

	public double getLenght() {
		return lenght;
	}

	public void setLenght(double lenght) {
		this.lenght = lenght;
	}

	public double getReplacement_cost() {
		return replacement_cost;
	}

	public void setReplacement_cost(double replacement_cost) {
		this.replacement_cost = replacement_cost;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public Date getLast_updade() {
		return last_updade;
	}

	public void setLast_updade(Date last_updade) {
		this.last_updade = last_updade;
	}

	public String getSpecial_features() {
		return special_features;
	}

	public void setSpecial_features(String special_features) {
		this.special_features = special_features;
	}

	public String getFulltext() {
		return fulltext;
	}

	public void setFulltext(String fulltext) {
		this.fulltext = fulltext;
	}

	@Override
	public String toString() {
		return "Film [film_id=" + film_id + ", title=" + title + ", description=" + description + ", release_year="
				+ release_year + ", language_id=" + language_id + ", rental_duration=" + rental_duration
				+ ", rental_rate=" + rental_rate + ", lenght=" + lenght + ", replacement_cost=" + replacement_cost
				+ ", rating=" + rating + ", last_updade=" + last_updade + ", special_features=" + special_features
				+ ", fulltext=" + fulltext + "]";
	}

	
}