package com.qintess.dvdrental;

import java.util.Scanner;

import com.qintess.dvdrental.dao.CustomerDao;
import com.qintess.dvdrental.dao.PaymentDao;
import com.qintess.dvdrental.dao.RentalDao;
import com.qintess.dvdrental.entidades.Customer;

public class Delete {

	public void delete( ) {

		Scanner sc = new Scanner(System.in);

		PaymentDao daoPayment = new PaymentDao();
		CustomerDao daoCust = new CustomerDao(null);
		RentalDao daoRental = new RentalDao();

		try {
			System.out.println("Deseja excluir: \r\n"
					+ "1 = Customer \r\n"
					);

			int escolha2 = sc.nextInt();
			System.out.println();
			Customer c = new Customer();

			if (escolha2 == 1) {
				System.out.println("====== DELETE =======");
				System.out.print("Digite o ID a ser deletado: ");
				int id = sc.nextInt();
				System.out.println(daoCust.buscaPorId(id));

				sc.nextLine();
				System.out.println("INATIVAR: O usuário será apenas inativado.");
				System.out.println("EXCLUIR: O usuário e todos os dados vinculados ao mesmo serão excluídos do banco de dados.");
				System.out.println();
				System.out.println("Deseja excluir ou inativar o usuário acima?");
				String rp = sc.nextLine();

				if (rp.equalsIgnoreCase("Excluir")) {					
					daoPayment.delete(id);
					daoRental.delete(id);
					daoCust.delete(id);

				} else {
					System.out.print(daoCust.alterarActive(id)); // RETIRAR O TRUE
					System.out.println("Cliente inativo.");
				}
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
}