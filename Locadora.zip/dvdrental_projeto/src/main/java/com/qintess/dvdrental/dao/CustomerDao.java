package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.entidades.Customer;
import com.qintess.dvdrental.entidades.City;
import com.qintess.dvdrental.entidades.Country;
import com.qintess.dvdrental.entidades.FullAddress;

public class CustomerDao implements DaoBase<Customer>{

	private Connection conn;
	public CustomerDao (Connection conn) {
		this.conn = conn;
	}
	
	@Override
	public Customer buscaPorId(int id) {

		Customer cust = null;

		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT customer_id, first_name, last_name, email, active FROM customer WHERE customer_id = ?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

				cust = new Customer();

				cust.setCustomerId(rs.getInt("customer_id"));
				cust.setFirstName(rs.getString("first_name"));
				cust.setLastName(rs.getString("last_name"));
				cust.setEmail(rs.getString("email"));
				cust.setActive(rs.getInt("active"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cust;
	}
	
	
	public Customer buscarCustomerEnderecoCompleto(int id) {
		
		Customer cust = null;
		City city = new City();
		Country country = new Country ();
		
		try(Connection conn = Conexao.abreConexao()) {
			
			String sql = "SELECT \r\n"
						+ "		c.customer_id, \r\n"
						+ "		c.first_name, \r\n"
						+ "		c.last_name, \r\n"
						+ "		c.email, \r\n"
						+ "		c.active, \r\n"
						+ "		a.address, \r\n"
						+ "		a.postal_code, \r\n"
						+ "		ci.city,\r\n"
						+ "		co.country\r\n"
						+ "FROM customer as c\r\n"
						+ "INNER JOIN address as a\r\n"
						+ "		on c.address_id = a.address_id\r\n"
						+ "INNER JOIN city as ci\r\n"
						+ "		on a.city_id = ci.city_id\r\n"
						+ "INNER JOIN country as co\r\n"
						+ "		on ci.country_id = co.country_id\r\n"
						+ "WHERE c.customer_id = ?";
				
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				cust = new Customer();
				
				cust.setCustomerId(rs.getInt("customer_id"));
				cust.setFirstName(rs.getString("first_name"));
				cust.setLastName(rs.getString("last_name"));
				cust.setEmail(rs.getString("email"));
				cust.setActive(rs.getInt("active"));
				
				FullAddress endereco = new FullAddress();
				
				endereco.setAddress(rs.getString("address"));
				endereco.setPostalCode(rs.getString("postal_code"));
				city.setCity(rs.getString("city"));
				country.setCountry(rs.getString("country"));
				
				cust.setFullAddress(endereco);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	return cust;
		
	}
	
	@Override 
	public boolean insere (Customer customer) {
		
		
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "INSERT INTO customer( "
					+ "store_id, first_name, last_name, email, address_id, active)"
					+ "VALUES (?, ?, ?, ?, ?, ?)";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, customer.getStoreId());
			pstmt.setString(2, customer.getFirstName());
			pstmt.setString(3, customer.getLastName());
			pstmt.setString(4, customer.getEmail());
			pstmt.setInt(5, customer.getFullAddress().getId());
			pstmt.setInt(6, customer.getActive());
			
			pstmt.executeUpdate();
			
			conn.commit();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}


	@Override
	public List<Customer> listaTodos() {
		 List<Customer> list = new ArrayList<Customer>();
		 
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "SELECT customer_id, store_id, first_name, last_name, email, address_id, activebool, create_date, last_update, active FROM customer";
		
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
			Customer c = new Customer();
			
			c.setCustomerId(rs.getInt("customer_id"));
			c.setStoreId(rs.getInt("store_id"));
			c.setFirstName(rs.getString("first_name"));		
			c.setLastName(rs.getString("last_name"));	
			c.setEmail(rs.getString("email"));		
			c.setAddressId(rs.getInt("address_id"));		
			c.setActivebool(rs.getBoolean("activebool"));
			c.setCreateDate(rs.getDate("create_date")); 
			c.setLastUpdate(rs.getDate("last_update")); 
			c.setActive(rs.getInt("active"));

			list.add(c);
			
			} 
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}


	@Override
	public boolean delete(int id) {
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "DELETE FROM customer WHERE customer_Id = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			int rs = pstmt.executeUpdate();
			if (rs > 0) {
				System.out.println("Customer deletado!");
			}
			conn.commit();
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	@Override
	public boolean altera(Customer entidade) {
		
		try(Connection conn = Conexao.abreConexao()) {

			String sql = "UPDATE customer SET store_id = ?, first_name = ?, last_name =?, email = ?,address_id = ?, activebool = ?, create_date =?, active=? where customer_id=?;";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, entidade.getStoreId());
			pstmt.setString(2, entidade.getFirstName());
			pstmt.setString(3, entidade.getLastName());
			pstmt.setString(4, entidade.getEmail());
			pstmt.setInt(5, entidade.getAddressId());
			pstmt.setBoolean(6, entidade.isActivebool());
			pstmt.setDate(7,entidade.getCreateDate());
			pstmt.setInt(8, entidade.getActive());
			pstmt.setInt(9, entidade.getCustomerId());

			pstmt.executeUpdate();
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public Customer customerInserido (Customer cust) {

		try(Connection conn = Conexao.abreConexao()) {
			String sqlUP = "SELECT * FROM customer WHERE customer_id = (SELECT MAX(CUSTOMER_ID) FROM CUSTOMER)";

			PreparedStatement pt = conn.prepareStatement(sqlUP);

			ResultSet rs = pt.executeQuery();

			while(rs.next()) {

				cust.setCustomerId(rs.getInt("customer_id"));
				cust.setStoreId(rs.getInt("store_id"));
				cust.setFirstName(rs.getString("first_name"));
				cust.setLastName(rs.getString("last_name"));
				cust.setEmail(rs.getString("email"));
				cust.setActive(rs.getInt("active"));
				cust.setLastUpdate(rs.getDate("last_update"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cust;
	}
	
	public Customer customerUpdate (Customer cust) {

		try(Connection conn = Conexao.abreConexao()) {
			String sqlUP = "SELECT * FROM customer WHERE last_update = (SELECT MAX(LAST_UPDATE) FROM CUSTOMER)";

			PreparedStatement pt = conn.prepareStatement(sqlUP);

			ResultSet rs = pt.executeQuery();

			while(rs.next()) {

				cust.setCustomerId(rs.getInt("customer_id"));
				cust.setFirstName(rs.getString("first_name"));
				cust.setLastName(rs.getString("last_name"));
				cust.setEmail(rs.getString("email"));
				cust.setActive(rs.getInt("active"));
				cust.setLastUpdate(rs.getDate("last_update"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cust;
	}

	public boolean alterarActive(int id) {

		try(Connection conn = Conexao.abreConexao()) {

			String sql = "UPDATE customer SET active = 0 where customer_id=?;";

			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, id);

			pstmt.executeUpdate();
			
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
				
		return false;
	}
}