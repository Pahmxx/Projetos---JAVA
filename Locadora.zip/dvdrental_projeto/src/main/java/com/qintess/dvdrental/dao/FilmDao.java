package com.qintess.dvdrental.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.ator.entidades.Film;

public class FilmDao  implements DaoBase<Film>{
	@Override
	public List<Film> listaTodos(){
		
		List<Film> list = new ArrayList<Film>();
		
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "SELECT film_id, title, description, release_year, language_id, rental_duration, rental_rate, length, replacement_cost, rating, last_update, special_features, fulltext FROM film";
	
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Film a = new Film();

				a.setFilme_id(rs.getInt("film_id"));
				a.setTitle(rs.getString("title"));
				a.setDescription(rs.getString("description"));
				a.setRelease_year(rs.getInt("release_year"));
				a.setLanguage_id(rs.getInt("language_id"));
				a.setRental_duration(rs.getDouble("rental_duration"));
				a.setRental_rate(rs.getDouble("rental_rate"));
				a.setLenght(rs.getDouble("length"));
				a.setReplacement_cost(rs.getDouble("replacement_cost"));
				a.setRating(rs.getString("rating"));
				a.setLast_updade(rs.getDate("last_update"));
				a.setSpecial_features(rs.getString("special_features"));
				a.setFulltext(rs.getString("fulltext"));

				list.add(a);

			} 	
			
		} catch (SQLException e){
			e.printStackTrace();
		}
		return list;
	}

	public boolean delete(int id) {
		return false;
	}
	
	@Override
	public boolean altera(Film entidade) {
		try(Connection conn = Conexao.abreConexao()) {

			String sql = "UPDATE film SET film_id=?, title=?, description=?, release_year=?, language_id=?, rental_duration=?, rental_rate=?, length=?, replacement_cost=?, rating=? ::mpaa_rating, special_features=?, fulltext=?";
					

			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, entidade.getFilme_id());
			pstmt.setString(2, entidade.getTitle());
			pstmt.setString(3, entidade.getDescription());
			pstmt.setInt(4, entidade.getRelease_year());
			pstmt.setInt(5, entidade.getLanguage_id());
			pstmt.setDouble(6, entidade.getRental_duration());
			pstmt.setDouble(7, entidade.getRental_rate());
			pstmt.setDouble(8, entidade.getLenght());
			pstmt.setDouble(9, entidade.getReplacement_cost());
			pstmt.setString(10, entidade.getRating());
			pstmt.setString(11, entidade.getSpecial_features());
			pstmt.setString(12, entidade.getFulltext());
			
			
			pstmt.executeUpdate();
			return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
}
	public boolean insere(Film film) {

		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);

			String sql = "INSERT INTO film(\r\n"
					+ " title, description, release_year, language_id, rental_duration, rental_rate, length, replacement_cost, rating, special_features)\r\n"
					+ "	VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?::mpaa_rating, ?::text[]);";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, film.getTitle());
			pstmt.setString(2, film.getDescription());
			pstmt.setInt(3, film.getRelease_year());
			pstmt.setInt(4, film.getLanguage_id());
			pstmt.setDouble(5, film.getRental_duration());
			pstmt.setDouble(6, film.getRental_rate());
			pstmt.setDouble(7, film.getLenght());
			pstmt.setDouble(8, film.getReplacement_cost());
			pstmt.setString(9, film.getRating());
			pstmt.setString(10, film.getSpecial_features());

			pstmt.executeUpdate();

			conn.commit();

       } catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	@Override
	public Film buscaPorId(int id) {
		Film film = null;

		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT film_id, title, description, release_year, language_id, rental_duration, rental_rate, length, replacement_cost, rating, last_update, special_features, fulltext FROM film WHERE film_id=?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {
				
				film = new Film();

				film.setFilme_id(rs.getInt("film_id"));
				film.setTitle(rs.getString("title"));
				film.setDescription(rs.getString("description"));
				film.setRelease_year(rs.getInt("release_year"));
				film.setLanguage_id(rs.getInt("language_id"));
				film.setRental_duration(rs.getDouble("rental_duration"));
				film.setRental_rate(rs.getDouble("rental_rate"));
				film.setLenght(rs.getDouble("length"));
				film.setReplacement_cost(rs.getDouble("replacement_cost"));
				film.setRating(rs.getString("rating"));
				film.setLast_updade(rs.getDate("last_update"));
				film.setSpecial_features(rs.getString("special_features"));
				film.setFulltext(rs.getString("fulltext"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return film;
	}
}