package com.qintess.dvdrental;

import java.util.Date;
import java.util.Scanner;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.qintess.dvdrental.dao.CityDao;
import com.qintess.dvdrental.dao.CountryDao;
import com.qintess.dvdrental.dao.CustomerDao;
import com.qintess.dvdrental.dao.FullAddressDao;
import com.qintess.dvdrental.dao.PaymentDao;
import com.qintess.dvdrental.dao.StaffDao;
import com.qintess.dvdrental.entidades.City;
import com.qintess.dvdrental.entidades.Country;
import com.qintess.dvdrental.entidades.Customer;
import com.qintess.dvdrental.entidades.FullAddress;
import com.qintess.dvdrental.entidades.Staff;

public class Update {

	public void update( ) {


		try {


			FullAddressDao daoFull = new FullAddressDao();
			CountryDao daoCountry = new CountryDao();
			CityDao daoCity = new CityDao();
			CustomerDao daoCust = new CustomerDao(null);
			PaymentDao daoPayment = new PaymentDao();
			StaffDao daoStaff = new StaffDao();

			Scanner sc = new Scanner(System.in);
			System.out.println("Deseja atualizar: \r\n"
					+ "1 = Customer \r\n"
					+ "2 = Address \r\n"
					+ "3 = Country \r\n"
					+ "4 = City \r\n"
					+ "5 = Staff \r\n"
					);

			int escolha = sc.nextInt();

			System.out.println();
			System.out.println("===== UPDATE =======");

			if (escolha == 1) {

				Customer c = new Customer();
				System.out.print("Digite o ID do cliente a ser atualizado: ");
				int idU = sc.nextInt();
				c.setCustomerId(idU);
				sc.nextLine();

				System.out.print("Digite o store_id: ");
				int storeUp = sc.nextInt();
				c.setStoreId(storeUp);

				System.out.print("Digite novo nome: ");
				String nomeUp = sc.next();
				c.setFirstName(nomeUp);

				System.out.print("Digite o novo sobrenome: ");
				String sobrenomeUp = sc.next();
				c.setLastName(sobrenomeUp);

				System.out.print("Digite o novo email: ");
				String emailUp = sc.next();
				c.setEmail(emailUp);

				System.out.print("Digite o adress_id: ");
				int addressUp = sc.nextInt();
				c.setAddressId(addressUp);

				System.out.print("Digite o activebool: ");
				boolean activeBoUp = sc.nextBoolean();
				c.setActivebool(activeBoUp);

//				System.out.print("Digite o create date: ");
//				String dataRecebida = sc.next();
//				DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
//				Date dt = df.parse(dataRecebida);
//				c.setPayment_date(dt);

				System.out.print("Digite o active: ");
				int active = sc.nextInt();
				c.setActive(active);

				if(daoCust.altera(c)){
					System.out.println();
					System.out.println("Novos dados:");
					System.out.println(daoCust.customerUpdate(c));
					System.out.println("Dados Alterados com sucesso!");

				}else {
					System.out.println("É necessario prencher todos os campos");
				}

			} if (escolha == 2) {

				FullAddress c = new FullAddress();

				System.out.print("Digite o ID do endereço a ser atualizado: ");
				int idU = sc.nextInt();
				c.setId(idU);
				sc.nextLine();

				System.out.print("Digite novo address: ");
				String addressUp = sc.nextLine();
				c.setAddress(addressUp);

				System.out.print("Digite o novo distrito: ");
				String distritoUp = sc.nextLine();
				c.setDistrict(distritoUp);

				System.out.print("Digite o novo phone: ");
				String phoneUp = sc.next();
				c.setPhone(phoneUp);

				System.out.print("Digite o novo postal code: ");
				String postalUp = sc.next();
				c.setPostalCode(postalUp);

				if(daoFull.altera(c)){
					System.out.println();
					System.out.println("Dados Alterados com sucesso!");

				} 
			}if (escolha == 3) {

				Country cou = new Country();

				System.out.print("Digite o ID a ser atualizado: ");
				int idUp = sc.nextInt();
				cou.setCountry_id(idUp);			
				
				System.out.print("Digite novo Country: ");
				String countryUp = sc.next();
				cou.setCountry(countryUp);

				if(daoCountry.altera(cou)){
					System.out.println("Dados Alterados com sucesso!");
				}

			} if (escolha == 4) {

				City cit = new City();

				System.out.print("Digite o ID a ser atualizado: ");
				int idUp = sc.nextInt();
				cit.setCity_id(idUp);	

				System.out.print("Digite  a nova City: ");
				String cityUp = sc.next();
				cit.setCity(cityUp);

				if(daoCity.altera(cit)){
					System.out.println();
					System.out.println("Dados Alterados com sucesso!");
				}

			} if (escolha == 5) {
				
				Staff staff = new Staff();
				
				System.out.print("Digite o ID do staff a ser atualizado: ");
				int idU = sc.nextInt();
				staff.setStaff_id(idU);
				sc.nextLine();
				
				System.out.print("Digite o nome: ");
				String nome = sc.next();
				staff.setFirst_name(nome);
				
				System.out.print("Digite o sobrenome: ");
				String sobrenome = sc.next();
				staff.setLast_name(sobrenome);	
				
				System.out.print("Digite o adress_id: ");
				int addressUp = sc.nextInt();
				staff.setAddress_id(addressUp);
				
				System.out.print("Digite o novo email: ");
				String emailUp = sc.next();
				staff.setEmail(emailUp);
				
				System.out.print("Digite o store_id: ");
				int storeUp = sc.nextInt();
				staff.setStore_id(storeUp);
				
				System.out.print("Digite o active: ");
				boolean active = sc.nextBoolean();
				staff.setActive(active);
				
				System.out.print("Digite o username: ");
				String user = sc.next();
				staff.setUsername(user);
				
				System.out.print("Digite o password: ");
				String pass = sc.next();
				staff.setPassword(pass);
				
				if(daoStaff.altera(staff)){
					System.out.println();
					System.out.println("Dados Alterados com sucesso!");
				}
				
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}