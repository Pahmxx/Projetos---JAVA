package com.qintess.dvdrental;

import java.util.Date;
import java.util.Scanner;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.qintess.dvdrental.dao.CityDao;
import com.qintess.dvdrental.dao.CountryDao;
import com.qintess.dvdrental.dao.CustomerDao;
import com.qintess.dvdrental.dao.FullAddressDao;
import com.qintess.dvdrental.dao.PaymentDao;
import com.qintess.dvdrental.dao.StaffDao;
import com.qintess.dvdrental.entidades.City;
import com.qintess.dvdrental.entidades.Country;
import com.qintess.dvdrental.entidades.Customer;
import com.qintess.dvdrental.entidades.FullAddress;
import com.qintess.dvdrental.entidades.Payment;
import com.qintess.dvdrental.entidades.Staff;
import com.qintess.dvdrental.entidades.Store;

public class Insert {

	public void insert( ) {

		try {

			Scanner sc = new Scanner(System.in);
			CountryDao daoCountry = new CountryDao();
			CityDao daoCity = new CityDao();
			StaffDao daoStaff = new StaffDao();
			PaymentDao daoPayment = new PaymentDao();
			FullAddressDao daoFull = new FullAddressDao();

			CustomerDao daoCust = new CustomerDao(null);
			Store Store = new Store();

			Store store = new Store();

			System.out.println("Deseja inserir: \r\n"
					+ "1 = Customer \r\n"
					+ "2 = Address \r\n"
					+ "3 = Country \r\n"
					+ "4 = City \r\n"
					+ "5 = Staff \r\n"
					+ "6 = Payment \r\n"
					);

			int escolha2 = sc.nextInt();

			System.out.println("====== INSERT =======");

			if (escolha2 == 1) {

				System.out.println("Qual a loja desejada? (1 ou 2)");
				int loja = sc.nextInt();
				Store.setId(loja);

				System.out.print("Digite o nome: ");
				String first = sc.next();

				System.out.print("Digite o sobrenome: ");
				String last = sc.next();

				System.out.print("Digite o email: ");
				String ema = sc.next();

				Customer customer = new Customer (0, loja, first, last, ema);
				customer.setActive(1);

				FullAddress add = new FullAddress();
				add.setId(1);

				customer.setStore(store);
				customer.setFullAddress(add);
				daoCust.insere(customer);


				System.out.println("Dados inseridos:" );
				System.out.println(daoCust.customerInserido(customer));
				System.out.println("Customer adicionado com sucesso!");

			} if (escolha2 == 2) {
				FullAddress c = new FullAddress();

				System.out.print("Digite o address: ");
				String address = sc.next();
				c.setAddress(address);

				System.out.print("Digite o distrito: ");
				String district = sc.next();
				c.setDistrict(district);

				System.out.print("Digite o city_id: ");
				int city = sc.nextInt();
				c.setCityId(city);

				System.out.print("Digite o novo postal code: ");
				String postal = sc.next();
				c.setPostalCode(postal);

				System.out.print("Digite o novo phone: ");
				String phone = sc.next();
				c.setPhone(phone);

				if(daoFull.insere(c)){
					System.out.println();
					System.out.println(daoFull.fullInserido(c));
					System.out.println("Dados inseridos com sucesso!");

				}

			} if (escolha2 == 3) {

				Country cou = new Country();

				System.out.print("Digite novo Country: ");
				String countryUp = sc.next();
				cou.setCountry(countryUp);

				if(daoCountry.insere(cou)){
					System.out.println();
					System.out.println(daoCountry.countryInserido(cou));
					System.out.println("Dados inseridos com sucesso!");
				}

			} if (escolha2 == 4) {

				City ci = new City();

				System.out.print("Digite a city: ");
				String cityInsert = sc.next();
				ci.setCity(cityInsert);

				System.out.print("Digite country_id: ");
				int countryInsert = sc.nextInt();
				ci.setCountry_id(countryInsert);

				City city = new City (0, cityInsert, countryInsert, null);
				if(daoCity.insere(ci)) {

					System.out.println();
					System.out.println(daoCity.cityInserido(city));
					System.out.println("Dados inseridos com sucesso!");
				}

			} if (escolha2 == 5) {

				Staff s = new Staff();

				System.out.print("Digite o nome: ");
				String nome = sc.next();
				s.setFirst_name(nome);

				System.out.print("Digite o sobrenome: ");
				String sobrenome = sc.next();
				s.setLast_name(sobrenome);

				System.out.print("Digite o adress_id: ");
				int addr = sc.nextInt();
				s.setAddress_id(addr);

				System.out.print("Digite o email: ");
				String email = sc.next();
				s.setEmail(email);
				sc.nextLine();

				System.out.print("Digite o store_id: ");
				int storeI = sc.nextInt();
				s.setStore_id(storeI);

				System.out.print("Digite o active: ");
				boolean active = sc.nextBoolean();
				s.setActive(active);

				System.out.print("Digite o username: ");
				String user = sc.next();
				s.setUsername(user);
				sc.nextLine();

				System.out.print("Digite o password: ");
				String pass = sc.next();
				s.setPassword(pass);

				if(daoStaff.insere(s)){
					System.out.println();
					System.out.println(daoStaff.staffInserido(s));
					System.out.println("Dados inseridos com sucesso!");
				}


			} if (escolha2 == 6) {

				Payment p = new Payment();

				System.out.print("Digite o customer_id: ");
				int cus = sc.nextInt();
				p.setCustomer_id(cus);

				System.out.print("Digite o staff_id: ");
				int staff = sc.nextInt();
				p.setStaff_id(staff);

				System.out.print("Digite o rental_id: ");
				int rental = sc.nextInt();
				p.setRental_id(rental);

				System.out.print("Digite novo pagamento: ");
				int amount = sc.nextInt();
				p.setAmount(amount);

				System.out.print("Digite a data do pagamento: ");
				String dataRecebida = sc.next();
				DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
				Date dt = df.parse(dataRecebida);
				p.setPayment_date(dt);
				
				Payment pay = new Payment (0, cus, null, rental, amount, staff);

				if(daoPayment.insere(p)){
					System.out.println();
					System.out.println(daoPayment.paymentInserido(pay));
					System.out.println("Dados inseridos com sucesso!");
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}


