package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.entidades.Customer;
import com.qintess.dvdrental.entidades.Rental;
import com.qintess.dvdrental.entidades.Staff;

public class RentalDao implements DaoBase<Rental> {

	@Override
	public List<Rental> listaTodos() {

		List<Rental> list = new ArrayList<Rental>();

		Rental r = new Rental();
		Customer customer = new Customer ();
		Staff staff = new Staff();

		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);

			String sql = "SELECT rental_id, rental_date, inventory_id, customer_id, return_date, staff_id, last_update FROM rental";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				Rental ren = new Rental();

				ren.setRental_id(rs.getInt("rental_id"));
				ren.setRental_date(rs.getDate("rental_date"));
				ren.setInventory_id(rs.getInt("inventory_id"));
				ren.setCustomer_id(rs.getInt("customer_id"));
				ren.setReturn_date(rs.getDate("return_date"));
				ren.setStaff_id(rs.getInt("staff_id"));
				ren.setLast_update(rs.getDate("last_update"));

				list.add(ren);
			}	

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;

	}

	@Override
	public Rental buscaPorId(int id) {
		Rental rental = null;

		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT rental_id, rental_date, inventory_id, customer_id, return_date, staff_id, last_update FROM rental where rental_id = ?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

				rental = new Rental();
				
				rental.setRental_id(rs.getInt("rental_id"));
				rental.setRental_date(rs.getDate("rental_date"));
				rental.setInventory_id(rs.getInt("inventory_id"));
				rental.setCustomer_id(rs.getInt("customer_id"));
				rental.setReturn_date(rs.getDate("return_date"));
				rental.setStaff_id(rs.getInt("staff_id"));
				rental.setLast_update(rs.getDate("last_update"));
			
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rental;
	}

	@Override
	public boolean delete(int id) {
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "DELETE FROM rental WHERE customer_id = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			int rs = pstmt.executeUpdate();
			if (rs > 0) {
				System.out.println("Rental deletado!");
			}
			conn.commit();
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	@Override
	public boolean altera(Rental entidade) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insere(Rental entidade) {
		// TODO Auto-generated method stub
		return false;
	}



}
