package com.qintess.dvdrental;

import java.util.Scanner;

public class App_Film {
	public static void main( String[] args )

	{

		Scanner sc = new Scanner(System.in);

		List_Film list = new List_Film();
		Insert_Film insert = new Insert_Film();
		Update_Film update = new Update_Film();
		
		BuscarPorId_Film buscarPorId = new BuscarPorId_Film();
		
		System.out.println();
		
		System.out.println("Digite a operação desejada");
		System.out.println ("Insere = 1 \r\n"
				+ "Deleta = 2 \r\n"
				+ "Lista  = 3 \r\n"
				+ "Update = 4 \r\n"
				+ "Buscar = 5 \r\n");

		int escolha = sc.nextInt();

		if (escolha == 1) {
			insert.insert_Film();

		} if (escolha == 2 ) {

		} if (escolha == 3) {
			list.list_film();
			
		} if (escolha == 4) {
			update.update_Film();
			
		} if (escolha == 5) {
			buscarPorId.buscarPorId_Film();
		}
	}
}

