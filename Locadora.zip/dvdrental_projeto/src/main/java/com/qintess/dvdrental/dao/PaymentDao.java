package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.entidades.Payment;

public class PaymentDao implements DaoBase<Payment> {


	@Override
	public boolean delete(int id) {
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "DELETE FROM payment WHERE customer_id = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			
			int rs = pstmt.executeUpdate();
			if (rs > 0) {
				System.out.println("Payment deletado!");
			}
			conn.commit();
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	@Override
	public boolean altera(Payment entidade) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean insere(Payment payment) {
				
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "INSERT INTO payment( "
					+ "customer_id, staff_id, rental_id, amount, payment_date)"
					+ "VALUES (?, ?, ?, ?, ?)";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
		
			pstmt.setInt(1, payment.getCustomer_id());
			pstmt.setInt(2, payment.getStaff_id());
			pstmt.setInt(3, payment.getRental_id());
			pstmt.setDouble(4, payment.getAmount());
			pstmt.setDate(5, new Date (payment.getPayment_date().getTime()));


			
			pstmt.executeUpdate();
			
			conn.commit();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}


	@Override
	public List<Payment> listaTodos() {
		 List<Payment> list = new ArrayList<Payment>();
		 
			try (Connection conn = Conexao.abreConexao()){
				conn.setAutoCommit(false);
				
			String sql = "SELECT payment_id, customer_id, staff_id, rental_id, amount, payment_date FROM payment";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
			Payment p = new Payment();

				p.setPayment_id(rs.getInt("payment_id"));
				p.setCustomer_id(rs.getInt("customer_id"));
				p.setStaff_id(rs.getInt("staff_id"));
				p.setRental_id(rs.getInt("rental_id"));
				p.setAmount(rs.getDouble("amount"));
				p.setPayment_date(rs.getDate("payment_date"));

				list.add(p);
			}	

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public Payment buscaPorId(int id) {

		Payment p = null;

		try(Connection conn = Conexao.abreConexao()) {
			
			String sql = "SELECT payment_id, customer_id, staff_id, rental_id, amount, payment_date FROM payment WHERE customer_id = ?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			
			ResultSet rs = pstmt.executeQuery();

			 while(rs.next()) {

				p = new Payment();

				p.setPayment_id(rs.getInt("payment_id"));
				p.setCustomer_id(rs.getInt("customer_id"));
				p.setStaff_id(rs.getInt("staff_id"));
				p.setRental_id(rs.getInt("rental_id"));
				p.setAmount(rs.getDouble("amount"));
				p.setPayment_date(rs.getDate("payment_date"));
			}
			
		
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return p;
	}
	
	public List< Payment > buscarPorId(int id) {
		
		Payment p = null;
		 List<Payment> list = new ArrayList<Payment>();
		 
		try(Connection conn = Conexao.abreConexao()) {
			
			String sql = "SELECT payment_id, customer_id, staff_id, rental_id, amount, payment_date FROM payment WHERE customer_id = ?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			
			ResultSet rs = pstmt.executeQuery();

			 while(rs.next()) {

				p = new Payment();

				p.setPayment_id(rs.getInt("payment_id"));
				p.setCustomer_id(rs.getInt("customer_id"));
				p.setStaff_id(rs.getInt("staff_id"));
				p.setRental_id(rs.getInt("rental_id"));
				p.setAmount(rs.getDouble("amount"));
				p.setPayment_date(rs.getDate("payment_date"));
				
				list.add(p);
			}
			
		
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}
	
	public Payment paymentInserido (Payment pa) {

		try(Connection conn = Conexao.abreConexao()) {
			String sqlUP = "SELECT * FROM payment WHERE payment_id = (SELECT MAX(PAYMENT_ID) FROM PAYMENT)";

			PreparedStatement pt = conn.prepareStatement(sqlUP);

			ResultSet rs = pt.executeQuery();

			while(rs.next()) {

				pa.setPayment_id(rs.getInt("payment_id"));
				pa.setCustomer_id(rs.getInt("customer_id"));
				pa.setStaff_id(rs.getInt("staff_id"));
				pa.setRental_id(rs.getInt("rental_id"));
				pa.setPayment_date(rs.getDate("payment_date"));
				pa.setAmount(rs.getInt("amount"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return pa;
	}
}
