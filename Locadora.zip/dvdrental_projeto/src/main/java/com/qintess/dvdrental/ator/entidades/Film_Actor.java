package com.qintess.dvdrental.ator.entidades;

import java.sql.Date;

public class Film_Actor {
	
	private int actor_id;
	private int film_id;
	private Date last_update;
		
	public Film_Actor() {}
	
	public Film_Actor(int actor_id, int film_id, Date last_update) {
		this.actor_id = actor_id;
		this.film_id = film_id;
		this.last_update = last_update;
	}

	public int getActor_id() {
		return actor_id;
	}

	public void setActor_id(int actor_id) {
		this.actor_id = actor_id;
	}

	public int getFilm_id() {
		return film_id;
	}

	public void setFilm_id(int i) {
		this.film_id = i;
	}

	public Date getLast_update() {
		return last_update;
	}

	public void setLast_update(Date last_update) {
		this.last_update = last_update;
	}

}