package com.qintess.dvdrental;

import java.util.Scanner;

import com.qintess.dvdrental.dao.ActorDao;
import com.qintess.dvdrental.dao.CategoryDao;
import com.qintess.dvdrental.dao.FilmDao;

public class BuscarPorId_Film {
	
	public void buscarPorId_Film( ) {
		
		CategoryDao daoCategory = new CategoryDao();
		FilmDao daoFilm = new FilmDao();
		ActorDao daoActor = new ActorDao();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Deseja buscar: \r\n"
				+ "1 = Categoria \r\n"
				+ "2 = Film \r\n"
				+ "3 = Actor \r\n"
				);

		int escolha = sc.nextInt();

		if (escolha == 1 ) {
			System.out.print("Digite o ID a ser buscado: ");
			int id = sc.nextInt();
			System.out.println(daoCategory.buscaPorId(id));
			
		} if (escolha == 2) {
			System.out.print("Digite o ID a ser buscado: ");
			int id = sc.nextInt();
			System.out.println(daoFilm.buscaPorId(id));
			
		} if (escolha == 3) {
			System.out.print("Digite o ID a ser buscado: ");
			int id = sc.nextInt();
			System.out.println(daoActor.buscaPorId(id));
		}
			
}
}
