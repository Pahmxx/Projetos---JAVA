package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.entidades.City;
import com.qintess.dvdrental.entidades.Country;
import com.qintess.dvdrental.entidades.Customer;

public class CityDao implements DaoBase<City> {

	@Override
	public List<City> listaTodos() {
		
		List<City> list = new ArrayList<City>();
		 
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "SELECT city_id, city, country_id, last_update FROM city";
		
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				
			City c = new City();
			Country country = new Country();
			
			c.setCity_id(rs.getInt("city_id"));
			c.setCity(rs.getString("city"));
			c.setLast_update(rs.getDate("last_update"));	
			c.setCountry_id(rs.getInt("country_id"));

			list.add(c);
			
			} 
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public City buscaPorId(int id) {
		
		City city = null;
		
		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT city_id, city, country_id, last_update FROM city WHERE city_id = ?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

				city = new City();
				
				city.setCity_id(rs.getInt("city_id"));
				city.setCity(rs.getString("city"));
				city.setCountry_id(rs.getInt("country_id"));
				city.setLast_update(rs.getDate("last_update"));
			
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return city;
	}

	@Override
	public boolean delete(int id) {
		
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "DELETE FROM city WHERE city_id = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			int rs = pstmt.executeUpdate();
			if (rs > 0) {
				System.out.println("City deletada!");
			}
			conn.commit();
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	@Override
	public boolean altera(City entidade) {
		try(Connection conn = Conexao.abreConexao()) {

			String sql = "UPDATE city SET city=? where city_id=?;";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			
			pstmt.setString(1, entidade.getCity());
			pstmt.setInt(2, entidade.getCity_id());
			
			pstmt.executeUpdate();
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	
	public boolean insere(City city) {

		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);	

			String sql = "INSERT INTO city (city, country_id) VALUES (?, ?)";

			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, city.getCity());
			pstmt.setInt(2, city.getCountry_id());

			pstmt.executeUpdate();

			conn.commit();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}
	
	public City cityInserido (City ci) {

		try(Connection conn = Conexao.abreConexao()) {
			String sqlUP = "SELECT * FROM city WHERE city_id = (SELECT MAX(CITY_ID) FROM CITY)";

			PreparedStatement pt = conn.prepareStatement(sqlUP);

			ResultSet rs = pt.executeQuery();

			while(rs.next()) {

				ci.setCity_id(rs.getInt("city_id"));
				ci.setCity(rs.getString("city"));
				ci.setCountry_id(rs.getInt("country_id"));
				ci.setLast_update(rs.getDate("last_update"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return ci;
	}

}
