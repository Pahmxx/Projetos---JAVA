package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.entidades.City;
import com.qintess.dvdrental.entidades.Country;
import com.qintess.dvdrental.entidades.Customer;
import com.qintess.dvdrental.entidades.FullAddress;

public class FullAddressDao implements DaoBase<FullAddress> {



	@Override
	public List<FullAddress> listaTodos( ) {

		List<FullAddress> list = new ArrayList<FullAddress>();

		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);

			String sql = "SELECT address_id, address,address2, district, postal_code, phone, city_id, last_update FROM address";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				FullAddress full = new FullAddress();

				full.setId(rs.getInt("address_id"));
				full.setAddress(rs.getString("address"));
				full.setAddress2(rs.getString("address2"));
				full.setDistrict(rs.getString("district"));
				full.setPostalCode(rs.getString("postal_code"));
				full.setPhone(rs.getString("phone"));
				full.setLastUpdate(rs.getDate("last_update"));
				full.setId(rs.getInt("city_id"));

				list.add(full);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return list;
	}

	@Override
	public FullAddress buscaPorId(int id) {

		FullAddress full = null;

		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT address_id, address, address2, district,phone,last_update,postal_code,city_id FROM address WHERE address_id = ?";
			//				tem que verificar pois a busca não esta por id customer e sim por adereço id

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

				full = new FullAddress();

				full.setId(rs.getInt("address_id"));
				full.setAddress(rs.getString("address"));
				full.setAddress2(rs.getString("address2"));
				full.setDistrict(rs.getString("district"));
				full.setPhone(rs.getString("phone"));
				full.setLastUpdate(rs.getDate("last_update"));
				full.setPostalCode(rs.getString("postal_code"));
				full.setCityId(rs.getInt("city_id"));


			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return full;		
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean altera(FullAddress entidade) {

		try(Connection conn = Conexao.abreConexao()) {

			String sql = "UPDATE address SET address = ?, address2 =?,  district = ?,phone = ?, "
					+ "postal_code= ? where address_id=?;";



			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, entidade.getAddress());
			pstmt.setString(2, entidade.getAddress2());
			pstmt.setString(3, entidade.getDistrict());
			pstmt.setString(4, entidade.getPhone());
			pstmt.setString(5, entidade.getPostalCode());
			pstmt.setInt(6,entidade.getId());


			pstmt.executeUpdate();
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}


	public boolean insere(FullAddress fullAddress) {


		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);

			String sql =  "INSERT INTO address ("
					+ "address, district, city_id, postal_code, phone)"
					+ " VALUES (?, ?, ?, ?, ?)";

			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, fullAddress.getAddress());
			pstmt.setString(2, fullAddress.getDistrict());
			pstmt.setInt(3, fullAddress.getCityId());
			pstmt.setString(4, fullAddress.getPostalCode());
			pstmt.setString(5, fullAddress.getPhone());

			pstmt.executeUpdate();

			conn.commit();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

		return true;

	}
	
	public FullAddress fullInserido (FullAddress full) {
		

		try(Connection conn = Conexao.abreConexao()) {
			String sqlUP = "SELECT * FROM address WHERE address_id =  (SELECT MAX(address_id) FROM address)";

			PreparedStatement pt = conn.prepareStatement(sqlUP);

			ResultSet rs = pt.executeQuery();

			while(rs.next()) {

				
				full.setId(rs.getInt("address_id"));
				full.setAddress(rs.getString("address"));
				full.setDistrict(rs.getString("district"));
				full.setCityId(rs.getInt("city_id"));
				full.setPostalCode(rs.getString("postal_code"));
				full.setPhone(rs.getString("phone"));
				full.setLastUpdate(rs.getDate("last_update"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return full;
	}
}