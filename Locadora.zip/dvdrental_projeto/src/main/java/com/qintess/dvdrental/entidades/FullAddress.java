package com.qintess.dvdrental.entidades;

import java.sql.Date;

public class FullAddress {

	private int id;
	private String address;
	private String address2;
	private String district;
	private String phone;
	private Date lastUpdate;
	private String postalCode;
	private int city_id; 
	private Country country;

	public FullAddress() {}

	public FullAddress(int id, String address, String address2, String district, String phone, Date lastUpdate,
			String postalCode, int cityId) {
		super();
		this.id = id;
		this.address = address;
		this.address2 = address2;
		this.district = district;
		this.phone = phone;
		this.lastUpdate = lastUpdate;
		this.postalCode = postalCode;
		this.city_id = city_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}


	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public int getCityId() {
		return city_id;
	}

	public void setCityId(int cityId) {
		this.city_id = cityId;
	}

	@Override
	public String toString() {
		return "FullAddress [id=" + id + ", address=" + address + ", address2=" + address2 + ", district=" + district
				+ ", phone=" + phone + ", lastUpdate=" + lastUpdate + ", postalCode=" + postalCode + ", cityId="
				+ city_id + "]";
	}
}
