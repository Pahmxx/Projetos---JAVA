package com.qintess.dvdrental;

import java.util.Locale;
import java.util.Scanner;

import com.qintess.dvdrental.ator.entidades.Actor;
import com.qintess.dvdrental.ator.entidades.Category;
import com.qintess.dvdrental.ator.entidades.Film;
import com.qintess.dvdrental.dao.ActorDao;
import com.qintess.dvdrental.dao.CategoryDao;
import com.qintess.dvdrental.dao.FilmDao;


public class Insert_Film {
	public void insert_Film( ) {

		Scanner sc = new Scanner(System.in);

		FilmDao daoFilm = new FilmDao();
		CategoryDao daoCategory = new CategoryDao();
		ActorDao daoActor = new ActorDao();
		
		System.out.println();

		System.out.println("Deseja inserir: \r\n"
				+ "1 = Categoria \r\n"
				+ "2 = Filme \r\n"
				+ "3 = Ator \r\n"
				);
		
		int escolha3 = sc.nextInt();
		
		System.out.println();
		System.out.println("====== INSERT =======");
		sc.nextLine();
		
		if (escolha3 == 1 ) {
			
			Category c = new Category();

			System.out.print("Digite a nova categoria a ser inserida: ");
			String ca = sc.next();
			c.setName(ca);
			
			if(daoCategory.insere(c)){
				System.out.println();
				System.out.println(daoCategory.categoryInserido(c));
				System.out.println("Categoria inserida com sucesso!");
			}
			
			
		} if (escolha3 == 2) {
			Film fil = new Film();

			System.out.print("Digite o nome do novo filme: ");
			String filUp = sc.next();
			sc.nextLine();
			fil.setTitle(filUp);

			System.out.print("Digite a nova Descrição: ");
			String descUp = sc.next();
			sc.nextLine();
			fil.setDescription(descUp);
			
			System.out.print("Digite o ano de lançamento: ");
			int relYerUp = sc.nextInt();
			sc.nextLine();
			fil.setRelease_year(relYerUp);
			
			System.out.print("Digite a linguagem: ");
			int lingua = sc.nextInt();
			fil.setLanguage_id(lingua);

			System.out.print("Digite qual a duração do aluguel: ");
			sc.useLocale(Locale.ENGLISH);
			Double renDurUp = sc.nextDouble();
			fil.setRental_duration(renDurUp);

			System.out.print("Digite qual a taxa do aluguel: ");
			Double renRatUp = sc.nextDouble();
			sc.nextLine();
			fil.setRental_rate(renRatUp);
			
			System.out.print("Digite qual o comprimento: ");
			Double lenUp = sc.nextDouble();
			sc.nextLine();
			fil.setLenght(lenUp);
			
			System.out.print("Digite qual o custo de reposição: ");
			Double repCostUp = sc.nextDouble();
			sc.nextLine();
			fil.setReplacement_cost(repCostUp);
			
			System.out.print("Digite a Avaliação: ");
			String ratUp = sc.next();
			sc.nextLine();
			fil.setRating(ratUp);
			
			System.out.print("Digite a características especiais: "); //COLOCAR ENTRE {}
			String specFeatUp = sc.next();
			sc.nextLine();
			fil.setSpecial_features(specFeatUp);
			
			System.out.print("Digite o texto completo: ");
			String fullTextUp = sc.next();
			sc.nextLine();
			fil.setFulltext(fullTextUp);
			
			if(daoFilm.insere(fil)){
				System.out.println();
				System.out.println("Dados inseridos com sucesso!");
		}
			
		} if (escolha3 == 3) {
			
			Actor a = new Actor();

			System.out.print("Digite o nome: ");
			String nome = sc.next();
			a.setFirst_name(nome);
			
			System.out.print("Digite o sobrenome: ");
			String sobrenome = sc.next();
			a.setLast_name(sobrenome);
			
			
			if(daoActor.insere(a)){
				System.out.println();
//				System.out.println(daoActor.actorInserido(a));
				System.out.println("Dados inseridos com sucesso!");
			}
		}
	}
}