package com.qintess.dvdrental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.qintess.dvdrental.entidades.Customer;
import com.qintess.dvdrental.entidades.Staff;

public class StaffDao implements DaoBase<Staff> {

	public List<Staff> listaTodos() {
		 List<Staff> list = new ArrayList<Staff>();
		 
			try (Connection conn = Conexao.abreConexao()){
				conn.setAutoCommit(false);
				
			String sql = "SELECT staff_id, first_name, last_name, address_id, email, store_id, active, username, password, last_update FROM Staff";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
			Staff stf = new Staff();

			stf.setStaff_id(rs.getInt("staff_id"));
			stf.setFirst_name(rs.getString("first_name"));
			stf.setLast_name(rs.getString("last_name"));
			stf.setAddress_id(rs.getInt("address_id"));
			stf.setEmail(rs.getString("email"));
			stf.setStore_id(rs.getInt("store_id"));
			stf.setActive(rs.getBoolean("active"));
			stf.setUsername(rs.getString("username"));
			stf.setPassword(rs.getString("password"));
			stf.setLast_update(rs.getDate("last_update"));
			
				list.add(stf);
			}	

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}


	@Override
	public Staff buscaPorId(int id) {
		Staff staff = null;

		try(Connection conn = Conexao.abreConexao()) {

			String sql = "SELECT staff_id, first_name, last_name, address_id, email, store_id, active, username, password, last_update FROM Staff WHERE staff_id = ?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);

			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

			staff = new Staff();

			staff.setStaff_id(rs.getInt("staff_id"));
			staff.setFirst_name(rs.getString("first_name"));
			staff.setLast_name(rs.getString("last_name"));
			staff.setAddress_id(rs.getInt("address_id"));
			staff.setEmail(rs.getString("email"));
			staff.setStore_id(rs.getInt("store_id"));
			staff.setActive(rs.getBoolean("active"));
			staff.setUsername(rs.getString("username"));
			staff.setPassword(rs.getString("password"));
			staff.setLast_update(rs.getDate("last_update"));
			
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return staff;
	}


	@Override
	public boolean delete(int id) {
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "DELETE FROM staff WHERE customer_Id = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			
			int rs = pstmt.executeUpdate();
			if (rs > 0) {
				System.out.println("Staff deletado!");
			}
			conn.commit();
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
		
	@Override
	public boolean altera(Staff entidade) {
		try(Connection conn = Conexao.abreConexao()) {

			String sql = "UPDATE staff SET  first_name=?, last_name=?, email=?, active=?, username=?, password=? where staff_id=?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, entidade.getFirst_name());
			pstmt.setString(2, entidade.getLast_name());
			pstmt.setString(3, entidade.getEmail());
			pstmt.setBoolean(4, entidade.isActive());
			pstmt.setString(5, entidade.getUsername());
			pstmt.setString(6, entidade.getPassword());
			pstmt.setInt(7, entidade.getStaff_id());
			
			pstmt.executeUpdate();
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean insere(Staff staff) {
		
		try (Connection conn = Conexao.abreConexao()){
			conn.setAutoCommit(false);
			
			String sql = "INSERT INTO staff( "
					+ "first_name, last_name, address_id, email, store_id, active, username, password)"
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, staff.getFirst_name());
			pstmt.setString(2, staff.getLast_name());
			pstmt.setInt(3, staff.getAddress_id());
			pstmt.setString(4, staff.getEmail());
			pstmt.setInt(5, staff.getStore_id());
			pstmt.setBoolean(6, staff.isActive());
			pstmt.setString(7, staff.getUsername());
			pstmt.setString(8, staff.getPassword());
			
			pstmt.executeUpdate();
			
			conn.commit();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	public Staff staffInserido (Staff staff) {
		Staff sta = null;

		try(Connection conn = Conexao.abreConexao()) {
			String sqlUP = "SELECT * FROM staff WHERE staff_id = (SELECT MAX(STAFF_ID) FROM STAFF)";

			PreparedStatement pt = conn.prepareStatement(sqlUP);

			ResultSet rs = pt.executeQuery();

			while(rs.next()) {

				sta = new Staff();
				
				sta.setStaff_id(rs.getInt("staff_id"));
				sta.setFirst_name(rs.getString("first_name"));
				sta.setLast_name(rs.getString("last_name"));
				sta.setAddress_id(rs.getInt("address_id"));
				sta.setEmail(rs.getString("email"));
				sta.setStore_id(rs.getInt("store_id"));
				sta.setActive(rs.getBoolean("active"));
				sta.setUsername(rs.getString("username"));
				sta.setPassword(rs.getString("password"));
				sta.setLast_update(rs.getDate("last_update"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return sta;
	}
}