package com.qintess.dvdrental;

import java.util.Scanner;

import com.qintess.dvdrental.dao.CityDao;
import com.qintess.dvdrental.dao.CountryDao;
import com.qintess.dvdrental.dao.CustomerDao;
import com.qintess.dvdrental.dao.FullAddressDao;
import com.qintess.dvdrental.dao.PaymentDao;
import com.qintess.dvdrental.dao.RentalDao;
import com.qintess.dvdrental.dao.StaffDao;
import com.qintess.dvdrental.dao.StoreDao;
import com.qintess.dvdrental.entidades.City;
import com.qintess.dvdrental.entidades.Country;
import com.qintess.dvdrental.entidades.Customer;
import com.qintess.dvdrental.entidades.FullAddress;
import com.qintess.dvdrental.entidades.Payment;
import com.qintess.dvdrental.entidades.Rental;
import com.qintess.dvdrental.entidades.Staff;
import com.qintess.dvdrental.entidades.Store;

public class List {

	public void list( ) {
		
		FullAddressDao daoFull = new FullAddressDao();
		CountryDao daoCountry = new CountryDao();
		CityDao daoCity = new CityDao();
		CustomerDao daoCust = new CustomerDao(null);
		StoreDao daoStore = new StoreDao();
		StaffDao daoStaff = new StaffDao();
		RentalDao daoRental = new RentalDao();
		PaymentDao daoPayment = new PaymentDao();

		Rental rental = new Rental ();

		Scanner sc = new Scanner(System.in);
		System.out.println("Deseja listar: \r\n"
				+ "1 = Customer \r\n"
				+ "2 = Address \r\n"
				+ "3 = Country \r\n"
				+ "4 = City \r\n"
				+ "5 = Staff \r\n"
				+ "6 = Store \r\n"
				+ "7 = Rental \r\n"
				+ "8 = Payment \r\n"
				);

		int escolha = sc.nextInt();

		System.out.println("===== LIST ===== ");

		if (escolha == 1) {
			for(Customer c : daoCust.listaTodos()){

				System.out.println(c.getCustomerId() + " | " + c.getStoreId() + " | " + 
						c.getFirstName() + " | " + c.getLastName() + " | " + c.getEmail() + " | " +
						c.getAddressId() + " | " + c.isActivebool() + " | " + c.getCreateDate() + " | " +
						c.getLastUpdate() + " | " + c.getActive()
						);
			}

		} if (escolha == 2) {
			for(FullAddress r : daoFull.listaTodos()){
				System.out.println(r.getId() + " | " + r.getAddress() + " | " + r.getDistrict() + " | " + r.getPostalCode() + " | " + r.getPhone() + " | " + r.getLastUpdate());
			}


		} if (escolha == 3) {
			for(Country c  : daoCountry.listaTodos()){
				System.out.println(c.getCountry_id() + " | " + c.getCountry() + " | " +  c.getLast_update());
			}

		} if (escolha == 4) {
			for(City c : daoCity.listaTodos()){
				System.out.println(c.getCity_id() + " | " + c.getCity() + " | " + c.getCountry_id()+ " | " + c.getLast_update());
			}

		} if (escolha == 5) {
			for(Staff s : daoStaff.listaTodos()){
				System.out.println(s.getStaff_id() + " | " + s.getFirst_name() + " | " + s.getLast_name() + " | " + s.getAddress_id() + " | " + s.getEmail() + " | " + s.getStore_id() + " | " + s.isActive() + " | " + s.getUsername() + " | " + s.getPassword() + " |" + s.getLast_update());
			}
			

		} if (escolha == 6) {
			for(Store s : daoStore.listaTodos()){
				System.out.println(s.getStore_id() + " | " + s.getManager_Staff_Id() + " | " + s.getFulladdress() + " | " + s.getLast_update());
			}

		} if (escolha == 7) {
			for(Rental rent : daoRental.listaTodos()){
				System.out.println(rent.getRental_id() + " | " + rent.getRental_date() + " | " + rent.getInventory_id() + " |" + rent.getCustomer_id() + " | " + rent.getReturn_date() + " | " + " | " + rent.getStaff_id() + " | " + rent.getLast_update());
			}

		} if (escolha == 8) {

			for(Payment p : daoPayment.listaTodos()){
				System.out.println(p.getPayment_id() + " | " + p.getCustomer_id() + " | " +
						p.getStaff_id() + " | " + p.getRental_id() + " | " + p.getAmount() + " | " +
						p.getPayment_date());		
			}
		}
	}
}