package com.docket.cartorio.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="endereco")
public class Endereco {

	@Id
	@Column(unique = true, nullable = true)
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int id;
	
	@Column(nullable = true)
	private String cep;
	
	@Column(name="ruaCartorio", nullable=true)	
	private String ruaCartorio;
	
	@Column(name="numCartorio")	
	private String numCartorio;
	
	@Column(name="bairroCartorio", nullable=true)	
	private String bairroCartorio;
	
	@Column(name="cidadeCartorio", nullable=true)	
	private String cidade;
	
	@Column(name="estadoCartorio", nullable=true)
	private String estado;

	public Endereco(int id, String cep, String ruaCartorio, String numCartorio, String bairroCartorio, String cidade,
			String estado) {
		this.id = id;
		this.cep = cep;
		this.ruaCartorio = ruaCartorio;
		this.numCartorio = numCartorio;
		this.bairroCartorio = bairroCartorio;
		this.cidade = cidade;
		this.estado = estado;
	}

	public Endereco() {}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getRuaCartorio() {
		return ruaCartorio;
	}

	public void setRuaCartorio(String ruaCartorio) {
		this.ruaCartorio = ruaCartorio;
	}

	public String getNumCartorio() {
		return numCartorio;
	}

	public void setNumCartorio(String numCartorio) {
		this.numCartorio = numCartorio;
	}

	public String getBairroCartorio() {
		return bairroCartorio;
	}

	public void setBairroCartorio(String bairroCartorio) {
		this.bairroCartorio = bairroCartorio;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

}
