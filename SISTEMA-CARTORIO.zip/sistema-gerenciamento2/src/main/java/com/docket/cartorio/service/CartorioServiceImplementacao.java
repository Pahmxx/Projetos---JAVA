package com.docket.cartorio.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.docket.cartorio.model.Cartorio;
import com.docket.cartorio.repository.CartorioRepository;

@Service
public class CartorioServiceImplementacao implements CartorioService{

	@Autowired
	private CartorioRepository cartorioRepository;
	
	@Autowired
	public CartorioServiceImplementacao(CartorioRepository cartorioRepository) {
		this.cartorioRepository = cartorioRepository;
	}

	@Override
	public Cartorio cadastraCartorio(Cartorio cartorio) {
		return cartorioRepository.save(cartorio);
	}
	
	// LISTA CARTÓRIOS

	@Override
	public List<Cartorio> listaDeCartorios() {
		return cartorioRepository.findAll();
	}
	
	// BUSCA CARTÓRIOS POR ID

	@Override
	public Optional<Cartorio> buscaCartorioPorID(Integer id) {
		Optional<Cartorio> cartorio = cartorioRepository.findById(id);
		
		if(!cartorio.isPresent())
			System.err.println("Cartório não encontrado, digite um número de ID válido.");
			return cartorio;
	}
	
	// EDITA CARTÓRIOS

	@Override
	public Cartorio editaCartorio(Cartorio cartorio, Integer id) {
		
		Optional<Cartorio> cartorioEdicao = cartorioRepository.findById(id);
		
		if (cartorioEdicao.isPresent()) {
			Cartorio cartorioEdicaoV = cartorioEdicao.get();
			cartorio.setId(cartorioEdicaoV.getId());
			cartorioRepository.save(cartorio);
			return cartorio;
		}
		
		return null;
	}
	
	// DELETA CARTÓRIOS

	@Override
	public Cartorio deletaCartorio(Integer id) {
		Optional<Cartorio> cartorio = cartorioRepository.findById(id);
		
		if(!cartorio.isPresent())
			System.err.println("Cartório não encontrado, digite um número de ID válido.");
		
		cartorioRepository.deleteById(id);
		return cartorio.get();
	}
}
