package com.docket.cartorio.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name="cartorio")
public class Cartorio {

	@Id
	@Column(unique = true, nullable = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "Nome_Cartorio", nullable = true)
	private String nomeCartorio;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "Data_Cadastro")
	private Date dataCadastro;	

	@OneToOne(cascade= CascadeType.ALL)
	@JoinColumn(name = "Endereco_ID", referencedColumnName = "id")
	private Endereco endereco;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "Cartorio_ID", referencedColumnName = "id")
	private List<Contato> contato;

	@OneToMany
	@JoinColumn(name = "Certidao_ID", referencedColumnName = "id")
	private List<Certidao> certidao;

	public Cartorio() {}

	public Cartorio(int id, String nomeCartorio, Date dataCadastro) {
		this.id = id;
		this.nomeCartorio = nomeCartorio;
		this.dataCadastro = dataCadastro;
	}


	@Autowired
	public Cartorio(int id, String nomeCartorio, Date dataCadastro, Endereco endereco, List<Contato> contato) {
		this.id = id;
		this.nomeCartorio = nomeCartorio;
		this.dataCadastro = dataCadastro;
		this.endereco = endereco;
		this.contato = contato;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public String getNomeCartorio() {
		return nomeCartorio;
	}

	public void setNomeCartorio(String nomeCartorio) {
		this.nomeCartorio = nomeCartorio;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public List<Contato> getContato() {
		return contato;
	}

	public void setContato(List<Contato> contato) {
		this.contato = contato;
	}

	public List<Certidao> getCertidao() {
		return certidao;
	}

	public void setCertidao(List<Certidao> certidao) {
		this.certidao = certidao;
	}

}

