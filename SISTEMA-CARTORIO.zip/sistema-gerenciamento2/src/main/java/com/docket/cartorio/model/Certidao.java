package com.docket.cartorio.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Certidao {

	@Id
	@Column(unique = true, nullable = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idCertidao;

	@Column(name = "Tipo_Certidao")
	private String tipoCertidao;

	@Column(name = "Nome_Certidao")
	private String nomeCertidao;

	@Column(name = "Tempo_Entrega")
	private String tempoEntrega;

	@ManyToOne
	private Cartorio cartorio;
	
	public Certidao(int idCertidao, String tipoCertidao, String nomeCertidao, String tempoEntrega) {
		this.idCertidao = idCertidao;
		this.tipoCertidao = tipoCertidao;
		this.nomeCertidao = nomeCertidao;
		this.tempoEntrega = tempoEntrega;
	}

	public Certidao() {}

	public Certidao(int idCertidao, String tipoCertidao, String nomeCertidao) {
		this.idCertidao = idCertidao;
		this.tipoCertidao = tipoCertidao;
		this.nomeCertidao = nomeCertidao;
	}

	public int getIdCertidao() {
		return idCertidao;
	}

	public void setIdCertidao(int idCertidao) {
		this.idCertidao = idCertidao;
	}

	public String getTipoCertidao() {
		return tipoCertidao;
	}

	public void setTipoCertidao(String tipoCertidao) {
		this.tipoCertidao = tipoCertidao;
	}

	public String getNomeCertidao() {
		return nomeCertidao;
	}

	public void setNomeCertidao(String nomeCertidao) {
		this.nomeCertidao = nomeCertidao;
	}

	public String getTempoEntrega() {
		return tempoEntrega;
	}

	public void setTempoEntrega(String tempoEntrega) {
		this.tempoEntrega = tempoEntrega;
	}

}
