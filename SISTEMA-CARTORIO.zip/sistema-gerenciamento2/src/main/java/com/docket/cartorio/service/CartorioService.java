package com.docket.cartorio.service;

import java.util.List;
import java.util.Optional;

import com.docket.cartorio.model.Cartorio;

public interface CartorioService {

	Cartorio cadastraCartorio(Cartorio cartorio);

	List<Cartorio> listaDeCartorios();

	Optional<Cartorio> buscaCartorioPorID(Integer id);

	Cartorio editaCartorio(Cartorio cartorio, Integer id);

	Cartorio deletaCartorio(Integer id);

}
