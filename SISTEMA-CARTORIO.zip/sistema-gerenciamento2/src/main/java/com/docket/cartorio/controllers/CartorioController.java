package com.docket.cartorio.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.docket.cartorio.model.Cartorio;
import com.docket.cartorio.service.CartorioService;

@RestController
@RequestMapping("/cartorio")
public class CartorioController {
	
	CartorioService cartorioService;
	
	@Autowired
	public CartorioController(CartorioService cartorioService) {
		this.cartorioService = cartorioService;
	}	
	 
	@GetMapping("/")
	public String viewHomePage(Model model) {
		List<Cartorio> listCartorio = cartorioService.listaDeCartorios();
		model.addAttribute("listCartorio", listCartorio);
		
		return "index";
	}

	// CADASTRO CARTÓRIO
	
	@PostMapping("/novo")
	public ResponseEntity<?> novoCartorio(@RequestBody Cartorio cartorio){

		try {	
			return new ResponseEntity<>(cartorioService.cadastraCartorio(cartorio), HttpStatus.CREATED);

		} catch(Exception e) {
			System.err.println("Erro ao cadastrar o cartório!");
			e.printStackTrace();
			return null;
		}
	}
	
	// LISTA CARTÓRIO
	
	@GetMapping("list")
	public ResponseEntity<?> listaCartorio() {
		List<Cartorio> cartorio = cartorioService.listaDeCartorios();

		if (cartorio.size()>0){
			return ResponseEntity.ok(cartorio);

		} else {
			System.err.println("Nenhum cartório cadastrado no sistema!");
			return null;
		}
	}
	
	
	// DELETA CARTÓRIO
	
	@DeleteMapping("delete/{id}")
	public ResponseEntity<?> DeletaProdutoVenda(@PathVariable(value = "id") Integer id) {	
		
		try {
			Cartorio cartorioDeletado = cartorioService.deletaCartorio(id);
			return ResponseEntity.ok("Cartorio correspondente ao ID: " + cartorioDeletado.getId() + ", deletado com sucesso!");
		
		} catch(Exception e){
			System.err.println("Nenhum cartório registrado com o ID informado!");
			e.printStackTrace();
			return null;
			
		}
	}
	
	
	// EDITA CARTÓRIO
	
	@PutMapping("update/{id}")
    public ResponseEntity<Cartorio> atualizaCartorio(Cartorio cartorio, @PathVariable(value = "id") Integer id) {
		System.out.println("Cartório atualizado com sucesso!");
        return new ResponseEntity<>(cartorioService.editaCartorio(cartorio, id), HttpStatus.OK);
    }
	
	// BUSCA POR ID
	
	@GetMapping("busca/{id}")
    public ResponseEntity<?> buscaCartorioById(@PathVariable(value = "id") Integer id) {
        Optional<Cartorio> cartorio  = cartorioService.buscaCartorioPorID(id);
        
        if (cartorio.isPresent()){
            return ResponseEntity.ok(cartorio);
        
        } else {
        	System.err.println("Nenhum cartório registrado com o ID informado!");
        	return null;
        }
    }
}

