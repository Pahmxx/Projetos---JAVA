package com.qintess.veterinaria.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Animal {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idAnimal;
	
	@Column(name="nomeAnimal")
	private String nomeAnimal;
	
	@Column(name="racaAnimal")
	private String racaAnimal;
	
	@Column(name="idadeAnimal")
	private String idadeAnimal;
	
	@ManyToOne(optional=true)
    @JoinColumn(referencedColumnName = "idDono")
	private Dono dono;
	
	public Animal() {
	}

	
	public Animal(int idAnimal, String nomeAnimal, String racaAnimal, String idadeAnimal) {
		super();
		this.idAnimal = idAnimal;
		this.nomeAnimal = nomeAnimal;
		this.racaAnimal = racaAnimal;
		this.idadeAnimal = idadeAnimal;
	}



	public Animal(int idAnimal, String nomeAnimal, String racaAnimal, String idadeAnimal, Dono dono) {
		super();
		this.idAnimal = idAnimal;
		this.nomeAnimal = nomeAnimal;
		this.racaAnimal = racaAnimal;
		this.idadeAnimal = idadeAnimal;
		this.dono = dono;
	}



	public int getIdAnimal() {
		return idAnimal;
	}
	public void setIdAnimal(int idAnimal) {
		this.idAnimal = idAnimal;
	}
	public String getNomeAnimal() {
		return nomeAnimal;
	}
	public void setNomeAnimal(String nomeAnimal) {
		this.nomeAnimal = nomeAnimal;
	}
	public String getRacaAnimal() {
		return racaAnimal;
	}
	public void setRacaAnimal(String racaAnimal) {
		this.racaAnimal = racaAnimal;
	}
	public String getIdadeAnimal() {
		return idadeAnimal;
	}
	public void setIdadeAnimal(String idadeAnimal) {
		this.idadeAnimal = idadeAnimal;
	}

	public Dono getDono() {
		return dono;
	}

	public void setDono(Dono dono) {
		this.dono = dono;
	}
	
	
	
}
