package com.qintess.veterinaria.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.qintess.veterinaria.dto.AnimalDto;
import com.qintess.veterinaria.dto.AtendimentoDto;
import com.qintess.veterinaria.dto.DonoDto;
import com.qintess.veterinaria.dto.VeterinarioDto;
import com.qintess.veterinaria.models.Atendimento;
import com.qintess.veterinaria.repositorios.AtendimentoRepository;
import com.qintess.veterinaria.repositorios.DonoRepository;
import com.qintess.veterinaria.repositorios.VeterinarioRepository;

@Controller
@RequestMapping("/atendimento")
public class AtendimentoController {
	
	@Autowired	
	private AtendimentoRepository atendimentoRepository;
	
	@Autowired	
	private DonoRepository donoRepository;
	
	@Autowired	
	private VeterinarioRepository veterinarioRepository;
	
	@GetMapping("/novo")
	public String novo(Model model) {
		model.addAttribute("atendimento", new AtendimentoDto());
		model.addAttribute("atendimentos", retornaAtendimentoDto());
		model.addAttribute("donos_agendamento", retornaDonoDto());
		model.addAttribute("veterinarios_agendamento", retornaVeterinarioDto());
		
		return "atendimento/novo";
	}
	
	@GetMapping("/finaliza")
	public String finaliza(Model model) {
		model.addAttribute("atendimento", new AtendimentoDto());
		model.addAttribute("atendimentos", retornaAtendimentoDto());
		model.addAttribute("donos_agendamento", retornaDonoDto());
		model.addAttribute("veterinarios_agendamento", retornaVeterinarioDto());
		
		return "atendimento/finaliza";
	}
	
	@PostMapping("/cadastra" )
	public String cadastra(AtendimentoDto atendimentoDto) {		
		Atendimento atendimento = atendimentoDto.conveter();
		atendimentoRepository.save(atendimento);
		return "redirect:/";
	}	
	
	
	private List <AtendimentoDto> retornaAtendimentoDto() {
		var atendimentoDto = new ArrayList<AtendimentoDto>();
		atendimentoRepository.findAll().forEach(a -> {
			atendimentoDto.add(new AtendimentoDto(a));
		
		});
		
		return atendimentoDto;
	}
	
	
	private List <DonoDto> retornaDonoDto() {
		var donoDto = new ArrayList<DonoDto>();
		donoRepository.findAll().forEach(d -> {
			donoDto.add(new DonoDto(d));
		
		});
		
		return donoDto;
	}
	
	private List <VeterinarioDto> retornaVeterinarioDto() {
		var veterinarioDto = new ArrayList<VeterinarioDto>();
		veterinarioRepository.findAll().forEach(v -> {
			veterinarioDto.add(new VeterinarioDto(v));

		});

		return veterinarioDto;
	}
	
	@GetMapping("/deleta/{id}")
	public String deleta(@PathVariable int id) {
		atendimentoRepository.deleteById(id);
		return "redirect:/";
	}
	
	@GetMapping("/edita/{id}")
	public String edita(@PathVariable int id, Model model) {
		
		var atendimentoOptional = atendimentoRepository.findById(id);
		if(atendimentoOptional.isPresent()) {
			var atendimento= atendimentoOptional.get();
			var atendimentoDto = new AtendimentoDto(atendimento);
			model.addAttribute("atendimento", atendimentoDto);
		}
		return "atendimento/novo";
	}
	
}
