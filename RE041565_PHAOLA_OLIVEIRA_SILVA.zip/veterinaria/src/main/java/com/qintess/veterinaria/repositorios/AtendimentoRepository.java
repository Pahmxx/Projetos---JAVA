package com.qintess.veterinaria.repositorios;

import org.springframework.data.repository.CrudRepository;

import com.qintess.veterinaria.models.Atendimento;

public interface AtendimentoRepository extends CrudRepository<Atendimento, Integer>{


	

}
