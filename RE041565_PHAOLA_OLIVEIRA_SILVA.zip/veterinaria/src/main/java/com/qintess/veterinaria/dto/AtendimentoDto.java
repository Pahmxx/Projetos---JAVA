package com.qintess.veterinaria.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.format.annotation.DateTimeFormat;

import com.qintess.veterinaria.models.Atendimento;
import com.qintess.veterinaria.models.Consulta;
import com.qintess.veterinaria.models.Dono;
import com.qintess.veterinaria.models.TipoConsulta;
import com.qintess.veterinaria.models.Veterinario;

public class AtendimentoDto {

	private int idAtendimento;
	private String dataAtendimento;
	private String horaAtendimento;
	private String tipoConsulta;
	private Consulta consulta;
	private Veterinario veterinario;
	private Dono dono;

	
	public AtendimentoDto() {}

	public AtendimentoDto(Atendimento a) {
		this.idAtendimento = a.getIdAtendimento();
		this.dataAtendimento = a.getDataAtendimento();
		this.horaAtendimento = a.getHoraAtendimento();
		this.tipoConsulta = a.getTipoConsulta();
		this.consulta = a.getConsulta();
		this.veterinario = a.getVeterinario();
		this.dono = a.getDono();


	}

	public int getIdAtendimento() {
		return idAtendimento;
	}

	public void setIdAtendimento(int idAtendimento) {
		this.idAtendimento = idAtendimento;
	}

	public String getDataAtendimento() {
		return dataAtendimento;
	}

	public void setDataAtendimento(String dataAtendimento) {
		this.dataAtendimento = dataAtendimento;
	}

	public String getTipoConsulta() {
		return tipoConsulta;
	}

	public void setTipoConsulta(String tipoConsulta) {
		this.tipoConsulta = tipoConsulta;
	}

	public Consulta getConsulta() {
		return consulta;
	}

	public void setConsulta(Consulta consulta) {
		this.consulta = consulta;
	}

	public Dono getDono() {
		return dono;
	}

	public void setDono(Dono dono) {
		this.dono = dono;
	}

	public Veterinario getVeterinario() {
		return veterinario;
	}

	public void setVeterinario(Veterinario veterinario) {
		this.veterinario = veterinario;
	}

	public Atendimento conveter() {
//		var att = LocalDate.parse(this.dataAtendimento,DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		return new Atendimento(this.idAtendimento, this.dataAtendimento, this.horaAtendimento, this.tipoConsulta,  this.consulta,  this.veterinario,this.dono);
	}

	public String getHoraAtendimento() {
		return horaAtendimento;
	}

	public void setHoraAtendimento(String horaAtendimento) {
		this.horaAtendimento = horaAtendimento;
	}
	
	

	
}
