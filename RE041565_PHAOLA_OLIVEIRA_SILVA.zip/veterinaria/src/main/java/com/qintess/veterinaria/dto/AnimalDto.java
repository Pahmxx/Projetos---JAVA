package com.qintess.veterinaria.dto;

import com.qintess.veterinaria.models.Animal;
import com.qintess.veterinaria.models.Dono;

public class AnimalDto {
	
	private int idAnimal;
	private String nomeAnimal;
	private String racaAnimal;
	private String idadeAnimal;
	private Dono dono;

	public AnimalDto() {
	}
	
	public AnimalDto(Animal a) {
		this.idAnimal = a.getIdAnimal();
		this.nomeAnimal = a.getNomeAnimal();
		this.racaAnimal = a.getRacaAnimal();
		this.idadeAnimal = a.getIdadeAnimal();
		this.dono = a.getDono();
	}
	
	public int getIdAnimal() {
		return idAnimal;
	}
	public void setIdAnimal(int idAnimal) {
		this.idAnimal = idAnimal;
	}
	public String getNomeAnimal() {
		return nomeAnimal;
	}
	public void setNomeAnimal(String nomeAnimal) {
		this.nomeAnimal = nomeAnimal;
	}
	public String getRacaAnimal() {
		return racaAnimal;
	}
	public void setRacaAnimal(String racaAnimal) {
		this.racaAnimal = racaAnimal;
	}
	public String getIdadeAnimal() {
		return idadeAnimal;
	}
	public void setIdadeAnimal(String idadeAnimal) {
		this.idadeAnimal = idadeAnimal;
	}

	public Animal conveter() {
		return new Animal(this.idAnimal, this.nomeAnimal, this.racaAnimal, this.idadeAnimal, this.dono);
	}

	@Override
	public String toString() {
		return "AnimalDto [idAnimal=" + idAnimal + ", nomeAnimal=" + nomeAnimal + ", racaAnimal=" + racaAnimal
				+ ", idadeAnimal=" + idadeAnimal + ", dono=" + dono + "]";
	}

	public Dono getDono() {
		return dono;
	}

	public void setDono(Dono dono) {
		this.dono = dono;
	}
}
