package com.qintess.veterinaria.models;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Veterinario {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idVeterinario;
	@Column
	private String crv;
	@Column
	private String nomeVeterinario;
	@Column
	private String telefoneVeterinario;
	@Column
	private String especialidade;
	
	@Embedded
	private Endereco endereco;
	
	public Veterinario() {
	}
	
	public Veterinario(int idVeterinario, String crv, String nomeVeterinario, String telefoneVeterinario,
			String especialidade, Endereco endereco) {
		this.idVeterinario = idVeterinario;
		this.crv = crv;
		this.nomeVeterinario = nomeVeterinario;
		this.telefoneVeterinario = telefoneVeterinario;
		this.especialidade = especialidade;
		this.endereco = endereco;
	}

	public String getCrv() {
		return crv;
	}
	public void setCrv(String crv) {
		this.crv = crv;
	}
	public String getNomeVeterinario() {
		return nomeVeterinario;
	}
	public void setNomeVeterinario(String nomeVeterinario) {
		this.nomeVeterinario = nomeVeterinario;
	}
	public String getTelefoneVeterinario() {
		return telefoneVeterinario;
	}
	public void setTelefoneVeterinario(String telefoneVeterinario) {
		this.telefoneVeterinario = telefoneVeterinario;
	}
	public String getEspecialidade() {
		return especialidade;
	}
	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}

	public int getIdVeterinario() {
		return idVeterinario;
	}

	public void setIdVeterinario(int idVeterinario) {
		this.idVeterinario = idVeterinario;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	

}
