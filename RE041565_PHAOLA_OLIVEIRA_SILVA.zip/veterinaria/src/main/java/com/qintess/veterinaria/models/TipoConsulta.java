package com.qintess.veterinaria.models;

public enum TipoConsulta {
	Agendada, Emergencia;
}
