package com.qintess.veterinaria.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Medicamento {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int idMedicamento;
	
	@Column
	private String nomeMedicamento;
	@Column
	private String horaAplicacao;
	@Column
	private String quantidade;
	
	@ManyToOne
	@JoinColumn(name = "idTratamento")
	private Tratamento tratamento;

	public String getHoraAplicacao() {
		return horaAplicacao;
	}
	public void setHoraAplicacao(String horaAplicacao) {
		this.horaAplicacao = horaAplicacao;
	}
	public String getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(String quantidade) {
		this.quantidade = quantidade;
	}
	public String getNomeMedicamento() {
		return nomeMedicamento;
	}
	public void setNomeMedicamento(String nomeMedicamento) {
		this.nomeMedicamento = nomeMedicamento;
	}
	public int getIdMedicamento() {
		return idMedicamento;
	}
	public void setIdMedicamento(int idMedicamento) {
		this.idMedicamento = idMedicamento;
	}
	
	

}
