package com.qintess.veterinaria.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.qintess.veterinaria.dto.DonoDto;
import com.qintess.veterinaria.models.Dono;
import com.qintess.veterinaria.repositorios.DonoRepository;

@Controller
@RequestMapping("/dono")
public class DonoController {
	
	@Autowired	
	private DonoRepository donoRepository;

	@GetMapping("/novo")
	public String novo(Model model) {
		model.addAttribute("dono", new DonoDto());
		model.addAttribute("donos", retornaDonoDto());
		
		return "dono/novo";
	}
	
	@PostMapping("/cadastra" )
	public String cadastra(DonoDto donoDto) {
		
		Dono dono = donoDto.conveter();
		donoRepository.save(dono);
		return "redirect:/";
	}	
	
	private List <DonoDto> retornaDonoDto() {
		var donoDto = new ArrayList<DonoDto>();
		donoRepository.findAll().forEach(d -> {
			donoDto.add(new DonoDto(d));
		
		});
		
		return donoDto;
	}
	
	@GetMapping("/deleta/{id}")
	public String deleta(@PathVariable int id) {
		donoRepository.deleteById(id);
		return "redirect:/";
	}
	
	
	@GetMapping("/edita/{id}")
	public String edita(@PathVariable int id, Model model) {
		
		var donoOptional = donoRepository.findById(id);
		if(donoOptional.isPresent()) {
			var dono = donoOptional.get();
			var donoDto = new DonoDto(dono);
			model.addAttribute("dono", donoDto);
		}
		return "dono/novo";
	}
	
}
