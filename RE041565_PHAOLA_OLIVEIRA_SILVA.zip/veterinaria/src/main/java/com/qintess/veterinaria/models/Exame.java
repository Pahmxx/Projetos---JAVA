package com.qintess.veterinaria.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Exame {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int idExame;
	private String nomeExame;
	private String valor;
	private String descrição;
	
	@ManyToOne()
	private Consulta consulta;
	
	public Exame() {
	}
	
	public Exame(int idExame, String nomeExame, String valor, String descrição, Consulta consulta) {
		this.idExame = idExame;
		this.nomeExame = nomeExame;
		this.valor = valor;
		this.descrição = descrição;
		this.consulta = consulta;
	}



	public Exame(int idExame, String nomeExame, String valor, String descrição) {
		this.idExame = idExame;
		this.nomeExame = nomeExame;
		this.valor = valor;
		this.descrição = descrição;
	}

	public Consulta getConsulta() {
		return consulta;
	}

	public void setConsulta(Consulta consulta) {
		this.consulta = consulta;
	}

	public int getIdExame() {
		return idExame;
	}
	public void setIdExame(int idExame) {
		this.idExame = idExame;
	}
	public String getNomeExame() {
		return nomeExame;
	}
	public void setNomeExame(String nomeExame) {
		this.nomeExame = nomeExame;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getDescrição() {
		return descrição;
	}

	public void setDescrição(String descrição) {
		this.descrição = descrição;
	}

	@Override
	public String toString() {
		return "Exame [idExame=" + idExame + ", nomeExame=" + nomeExame + ", valor=" + valor + ", descrição="
				+ descrição + ", consulta=" + consulta + "]";
	}
	
	

}
