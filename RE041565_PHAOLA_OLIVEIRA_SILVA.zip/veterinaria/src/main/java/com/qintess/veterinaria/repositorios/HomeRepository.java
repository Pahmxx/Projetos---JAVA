package com.qintess.veterinaria.repositorios;

import org.springframework.data.repository.CrudRepository;

import com.qintess.veterinaria.models.Animal;

public interface HomeRepository extends CrudRepository<Animal, Integer>{


}
