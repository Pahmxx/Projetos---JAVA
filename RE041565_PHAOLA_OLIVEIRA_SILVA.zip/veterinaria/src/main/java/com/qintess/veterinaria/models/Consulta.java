package com.qintess.veterinaria.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class Consulta {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idConsulta;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "consulta")
	private List<Exame> exames;
	
	@Column(name="diagnostico")
	private String diagnostico;
	
	@ManyToOne(optional=true)
    @JoinColumn(referencedColumnName = "idTratamento", nullable = false)
	private Tratamento tratamento;
	
	@OneToOne
	private Veterinario veterinario;

	public Consulta() {
	}
	
	public Consulta(int idConsulta, List<Exame> exames, String diagnostico, Tratamento tratamento,
			Veterinario veterinario) {
		this.idConsulta = idConsulta;
		this.exames = exames;
		this.diagnostico = diagnostico;
		this.tratamento = tratamento;
		this.veterinario = veterinario;
	}



	public List<Exame> getExames() {
		return exames;
	}
	public void setExames(List<Exame> exames) {
		this.exames = exames;
	}
	public String getDiagnostico() {
		return diagnostico;
	}
	public void setDiagnostico(String diagnostico) {
		this.diagnostico = diagnostico;
	}
	public Tratamento getTratamento() {
		return tratamento;
	}
	public void setTratamento(Tratamento tratamento) {
		this.tratamento = tratamento;
	}
	public Veterinario getVeterinario() {
		return veterinario;
	}
	public void setVeterinario(Veterinario veterinario) {
		this.veterinario = veterinario;
	}
	
}
