package com.qintess.veterinaria.models;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Atendimento {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idAtendimento;
	
	private String dataAtendimento;
	private String horaAtendimento;
	private String tipoConsulta;
	
	@OneToOne
	private Consulta consulta;
	
	@OneToOne
	public Cliente cliente;
	
	@OneToOne
	public Veterinario veterinario;
	
	@OneToOne
	public Dono dono;

	public Atendimento() {

	}


	

	public Atendimento(int idAtendimento, String dataAtendimento, String horaAtendimento, String tipoConsulta,
			Consulta consulta, Veterinario veterinario, Dono dono) {
		this.idAtendimento = idAtendimento;
		this.dataAtendimento = dataAtendimento;
		this.horaAtendimento = horaAtendimento;
		this.tipoConsulta = tipoConsulta;
		this.consulta = consulta;
		this.veterinario = veterinario;
		this.dono = dono;
	}




	public Atendimento(int idAtendimento, String dataAtendimento, String tipoConsulta, Consulta consulta,
			Cliente cliente, Veterinario veterinario, Dono dono) {
		super();
		this.idAtendimento = idAtendimento;
		this.dataAtendimento = dataAtendimento;
		this.tipoConsulta = tipoConsulta;
		this.consulta = consulta;
		this.cliente = cliente;
		this.veterinario = veterinario;
		this.dono = dono;
	}



	public int getIdAtendimento() {
		return idAtendimento;
	}

	public void setIdAtendimento(int idAtendimento) {
		this.idAtendimento = idAtendimento;
	}

	public String getDataAtendimento() {
		return dataAtendimento;
	}

	public void setDataAtendimento(String dataAtendimento) {
		this.dataAtendimento = dataAtendimento;
	}

	public Consulta getConsulta() {
		return consulta;
	}

	public void setConsulta(Consulta consulta) {
		this.consulta = consulta;
	}

	public String getTipoConsulta() {
		return tipoConsulta;
	}

	public void setTipoConsulta(String tipoConsulta) {
		this.tipoConsulta = tipoConsulta;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Dono getDono() {
		return dono;
	}

	public void setDono(Dono dono) {
		this.dono = dono;
	}

	public Veterinario getVeterinario() {
		return veterinario;
	}

	public void setVeterinario(Veterinario veterinario) {
		this.veterinario = veterinario;
	}



	public String getHoraAtendimento() {
		return horaAtendimento;
	}



	public void setHoraAtendimento(String horaAtendimento) {
		this.horaAtendimento = horaAtendimento;
	}

	
	
}
