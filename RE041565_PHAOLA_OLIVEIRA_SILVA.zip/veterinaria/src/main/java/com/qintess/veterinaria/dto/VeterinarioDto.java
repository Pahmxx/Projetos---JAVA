package com.qintess.veterinaria.dto;

import com.qintess.veterinaria.models.Endereco;
import com.qintess.veterinaria.models.Veterinario;

public class VeterinarioDto {
	
	private int idVeterinario;
	private String crv;
	private String nomeVeterinario;
	private String telefoneVeterinario;
	private String especialidade;
	private Endereco endereco;
	
	public VeterinarioDto() {
	}

	public VeterinarioDto(Veterinario v) {
		this.idVeterinario = v.getIdVeterinario();
		this.crv = v.getCrv();
		this.nomeVeterinario = v.getNomeVeterinario();
		this.telefoneVeterinario = v.getTelefoneVeterinario();
		this.especialidade = v.getEspecialidade();
		this.setEndereco(v.getEndereco());
	}


	public int getIdVeterinario() {
		return idVeterinario;
	}


	public void setIdVeterinario(int idVeterinario) {
		this.idVeterinario = idVeterinario;
	}

	public String getNomeVeterinario() {
		return nomeVeterinario;
	}


	public void setNomeVeterinario(String nomeVeterinario) {
		this.nomeVeterinario = nomeVeterinario;
	}


	public String getTelefoneVeterinario() {
		return telefoneVeterinario;
	}


	public void setTelefoneVeterinario(String telefoneVeterinario) {
		this.telefoneVeterinario = telefoneVeterinario;
	}


	public String getEspecialidade() {
		return especialidade;
	}


	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}

	public String getCrv() {
		return crv;
	}


	public void setCrv(String crv) {
		this.crv = crv;
	}


	public Veterinario conveter() {
		return new Veterinario(this.idVeterinario, this.crv, this.nomeVeterinario, this.telefoneVeterinario, this.especialidade, this.endereco);
	}

	@Override
	public String toString() {
		return nomeVeterinario + " | " + especialidade;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
}
