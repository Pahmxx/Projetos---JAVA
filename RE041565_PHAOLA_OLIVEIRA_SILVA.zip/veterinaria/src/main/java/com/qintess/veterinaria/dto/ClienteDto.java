package com.qintess.veterinaria.dto;

public class ClienteDto {

//	public int idCliente;
//	public String nomeDono;
//	public String nomeAnimal;
//	
//	public ClienteDto() {
//	}
//	
//	public ClienteDto(Cliente c) {
//		this.idCliente = c.getIdCliente();
//		this.nomeDono = c.getDono().getNomeDono();
//		this.nomeAnimal = c.getAnimal().getNomeAnimal();
//	}
//	public int getIdCliente() {
//		return idCliente;
//	}
//	public void setIdCliente(int idCliente) {
//		this.idCliente = idCliente;
//	}
//	public String getNomeDono() {
//		return nomeDono;
//	}
//	public void setNomeDono(String nomeDono) {
//		this.nomeDono = nomeDono;
//	}
//	public String getNomeAnimal() {
//		return nomeAnimal;
//	}
//	public void setNomeAnimal(String nomeAnimal) {
//		this.nomeAnimal = nomeAnimal;
//	}
//
//	public Cliente conveter() {
//		return new Cliente(this.idCliente, this.nomeAnimal, this.nomeDono);
//	}
//	
//	

}
