package com.qintess.veterinaria.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Dono {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idDono;
	
	@Column
	private String cpfDono;
	@Column
	private String nomeDono;
	@Column
	private String telefone;

	@Embedded
	private Endereco endereco;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "dono")
	private List<Animal> animal;

	

	public Dono() {
		
	}


	public Dono(int idDono, String cpfDono, String nomeDono, String telefone, Endereco endereco) {
		this.idDono = idDono;
		this.cpfDono = cpfDono;
		this.nomeDono = nomeDono;
		this.telefone = telefone;
		this.endereco = endereco;
	}


	public Dono(int idDono, String cpfDono, String nomeDono, String telefone, Endereco endereco, List<Animal> animal) {
		super();
		this.idDono = idDono;
		this.cpfDono = cpfDono;
		this.nomeDono = nomeDono;
		this.telefone = telefone;
		this.endereco = endereco;
		this.animal = animal;
	}


	public String getCpfDono() {
		return cpfDono;
	}
	public void setCpfDono(String cpfDono) {
		this.cpfDono = cpfDono;
	}
	public String getNomeDono() {
		return nomeDono;
	}
	public void setNomeDono(String nomeDono) {
		this.nomeDono = nomeDono;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public int getIdDono() {
		return idDono;
	}
	public void setIdDono(int idDono) {
		this.idDono = idDono;
	}

	public List<Animal> getAnimal() {
		return animal;
	}

	public void setAnimal(List<Animal> animal) {
		this.animal = animal;
	}


	public Endereco getEndereco() {
		return endereco;
	}


	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	
	
}
