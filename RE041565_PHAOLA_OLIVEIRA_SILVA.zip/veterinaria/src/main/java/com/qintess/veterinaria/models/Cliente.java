package com.qintess.veterinaria.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Cliente {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int idCliente;
	
	@OneToOne
	public Dono dono;
	
	@OneToOne
	public Animal animal;

	public Cliente(int idCliente, Dono dono, Animal animal) {
		this.idCliente = idCliente;
		this.dono = dono;
		this.animal = animal;
	
	}

	public Cliente(int idCliente2, String nomeAnimal, String nomeDono) {
		
	}

	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public Dono getDono() {
		return dono;
	}

	public void setDono(Dono dono) {
		this.dono = dono;
	}

	public Animal getAnimal() {
		return animal;
	}

	public void setAnimal(Animal animal) {
		this.animal = animal;
	}
	
	
}
