package com.qintess.veterinaria.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.qintess.veterinaria.dto.ExameDto;
import com.qintess.veterinaria.models.Exame;
import com.qintess.veterinaria.repositorios.ExameRepository;

@Controller
@RequestMapping("/exame")
public class ExameController {

	@Autowired	
	private ExameRepository exameRepository;

	@GetMapping("/novo")
	public String novo(Model model) {
		model.addAttribute("exame", new ExameDto());
		model.addAttribute("exames", retornaExameDto());
		return "exame/novo";
	}

	@PostMapping("/cadastra" )
	public String cadastra(ExameDto exameDto) {

		Exame exame = exameDto.conveter();
		exameRepository.save(exame);
		return "redirect:/";
	}
	
	private List <ExameDto> retornaExameDto() {
		var exameDto = new ArrayList<ExameDto>();
		exameRepository.findAll().forEach(e -> {
			exameDto.add(new ExameDto(e));
		
		});
		
		return exameDto;
	}

	@GetMapping("/deleta/{id}")
	public String deleta(@PathVariable int id) {
		exameRepository.deleteById(id);
		return "redirect:/";
	}
	
	@GetMapping("/edita/{id}")
	public String edita(@PathVariable int id, Model model) {
		
		var exameOptional = exameRepository.findById(id);
		if(exameOptional.isPresent()) {
			var exame = exameOptional.get();
			var exameDto = new ExameDto(exame);
			model.addAttribute("exame", exameDto);
		}
		return "exame/novo";
	}

}
