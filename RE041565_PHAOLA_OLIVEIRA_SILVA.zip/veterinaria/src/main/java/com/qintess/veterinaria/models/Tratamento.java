package com.qintess.veterinaria.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "tratamento")
public class Tratamento {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int idTratamento;

	@OneToMany(mappedBy = "tratamento")
	private List<Medicamento> medicamento;

	private String descricaoTratamento;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "tratamento")
	private List <Consulta> consulta;
	
	
	public Tratamento() {
	}


	public Tratamento(int idTratamento, List<Medicamento> medicamento, String descricaoTratamento, Consulta consulta) {
		super();
		this.idTratamento = idTratamento;
		this.medicamento = medicamento;
		this.descricaoTratamento = descricaoTratamento;
		this.consulta = (List<Consulta>) consulta;
	}

	public int getIdTratamento() {
		return idTratamento;
	}
	public void setIdTratamento(int idTratamento) {
		this.idTratamento = idTratamento;
	}
	
	public String getDescricaoTratamento() {
		return descricaoTratamento;
	}
	public void setDescricaoTratamento(String descricaoTratamento) {
		this.descricaoTratamento = descricaoTratamento;
	}

	public List<Consulta> getConsulta() {
		return consulta;
	}

	public void setConsulta(List<Consulta> consulta) {
		this.consulta = consulta;
	}


	public List<Medicamento> getMedicamento() {
		return medicamento;
	}


	public void setMedicamento(List<Medicamento> medicamento) {
		this.medicamento = medicamento;
	}

}
