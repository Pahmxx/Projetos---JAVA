package com.qintess.veterinaria.dto;

import com.qintess.veterinaria.models.Dono;
import com.qintess.veterinaria.models.Endereco;

public class DonoDto {

	private int idDono;
	private String cpfDono;
	private String nomeDono;
	private String telefone;
	private Endereco endereco;
	
	public DonoDto() {
	}

	public DonoDto(Dono d) {
		this.idDono = d.getIdDono();
		this.cpfDono = d.getCpfDono();
		this.nomeDono = d.getNomeDono();
		this.telefone = d.getTelefone();
		this.endereco = d.getEndereco();
		
	}


	public String getCpfDono() {
		return cpfDono;
	}


	public void setCpfDono(String cpfDono) {
		this.cpfDono = cpfDono;
	}


	public String getNomeDono() {
		return nomeDono;
	}


	public void setNomeDono(String nomeDono) {
		this.nomeDono = nomeDono;
	}


	public String getTelefone() {
		return telefone;
	}


	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public Dono conveter() {
		return new Dono(idDono, this.cpfDono, this.nomeDono, this.telefone, this.endereco);
	}

	public int getIdDono() {
		return idDono;
	}

	public void setIdDono(int idDono) {
		this.idDono = idDono;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	@Override
	public String toString() {
		return nomeDono + " | " + cpfDono;
	}
}
