package com.qintess.veterinaria.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.qintess.veterinaria.dto.AnimalDto;
import com.qintess.veterinaria.dto.AtendimentoDto;
import com.qintess.veterinaria.dto.DonoDto;
import com.qintess.veterinaria.dto.ExameDto;
import com.qintess.veterinaria.dto.VeterinarioDto;
import com.qintess.veterinaria.models.Exame;
import com.qintess.veterinaria.repositorios.AtendimentoRepository;
import com.qintess.veterinaria.repositorios.DonoRepository;
import com.qintess.veterinaria.repositorios.ExameRepository;
import com.qintess.veterinaria.repositorios.HomeRepository;
import com.qintess.veterinaria.repositorios.VeterinarioRepository;

@Controller
public class HomeController {

	@Autowired	
	private AtendimentoRepository atendimentoRepository;
	
	@Autowired	
	private DonoRepository donoRepository;
	
	@Autowired	
	private VeterinarioRepository veterinarioRepository;
	
	@Autowired	
	private HomeRepository homeRepository;
	
	@Autowired	
	private ExameRepository exameRepository;
	
	
	@GetMapping("")
	public String home(Model model) {
		model.addAttribute("atendimentos", retornaAtendimentoDto());
		model.addAttribute("exame_agendamento", retornaExameDto());
		model.addAttribute("donos_agendamento", retornaDonoDto());
		model.addAttribute("veterinarios_agendamento", retornaVeterinarioDto());
		
		return "index";
	}
	
	
	private List <AtendimentoDto> retornaAtendimentoDto() {
		var atendimentoDto = new ArrayList<AtendimentoDto>();
		atendimentoRepository.findAll().forEach(a -> {
			atendimentoDto.add(new AtendimentoDto(a));
		
		});
		
		return atendimentoDto;
	}

	private List <ExameDto> retornaExameDto() {
		var exameDto = new ArrayList<ExameDto>();
		exameRepository.findAll().forEach(e -> {
			exameDto.add(new ExameDto(e));
		
		});
		
		return exameDto;
	}
	
	private List <DonoDto> retornaDonoDto() {
		var donoDto = new ArrayList<DonoDto>();
		donoRepository.findAll().forEach(d -> {
			donoDto.add(new DonoDto(d));
		
		});
		
		return donoDto;
	}
	
	private List <VeterinarioDto> retornaVeterinarioDto() {
		var veterinarioDto = new ArrayList<VeterinarioDto>();
		veterinarioRepository.findAll().forEach(v -> {
			veterinarioDto.add(new VeterinarioDto(v));

		});

		return veterinarioDto;
	}
	
}

