package com.qintess.veterinaria.dto;

import com.qintess.veterinaria.models.Exame;

public class ExameDto {

	private int idExame;
	private String nomeExame;
	private String valor;
	private String descricao;
	
	public ExameDto() {
	}
	

	public ExameDto(Exame e) {
		this.idExame = e.getIdExame();
		this.nomeExame = e.getNomeExame();
		this.valor = e.getValor();
		this.descricao = e.getDescrição();
	}
	

	public int getIdExame() {
		return idExame;
	}


	public void setIdExame(int idExame) {
		this.idExame = idExame;
	}


	public String getNomeExame() {
		return nomeExame;
	}


	public void setNomeExame(String nomeExame) {
		this.nomeExame = nomeExame;
	}


	public String getValor() {
		return valor;
	}


	public void setValor(String valor) {
		this.valor = valor;
	}


	public Exame conveter() {
		return new Exame(this.idExame, this.nomeExame, this.valor, this.descricao);
	}


	public String getDescricao() {
		return descricao;
	}


	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
