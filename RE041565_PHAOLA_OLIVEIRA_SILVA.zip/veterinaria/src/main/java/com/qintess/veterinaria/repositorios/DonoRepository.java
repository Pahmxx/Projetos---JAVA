package com.qintess.veterinaria.repositorios;

import org.springframework.data.repository.CrudRepository;

import com.qintess.veterinaria.models.Dono;

public interface DonoRepository extends CrudRepository<Dono, Integer>{

}
