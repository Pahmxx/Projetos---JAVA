package com.qintess.veterinaria.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.qintess.veterinaria.dto.AnimalDto;
import com.qintess.veterinaria.dto.DonoDto;
import com.qintess.veterinaria.models.Animal;
import com.qintess.veterinaria.repositorios.AnimalRepository;
import com.qintess.veterinaria.repositorios.DonoRepository;

@Controller
@RequestMapping("/animal")
public class AnimalController {
	
	@Autowired	
	private AnimalRepository animalRepository;
	
	@Autowired	
	private DonoRepository donoRepository;

	@GetMapping("/novo")
	public String novo(Model model) {
		model.addAttribute("animal", new AnimalDto());
		model.addAttribute("animais", retornAnimalDto());
		model.addAttribute("donos_cad", retornaDonoDto());
		return "animal/novo";
	}
	
	@PostMapping("/cadastra" )
	public String cadastra(AnimalDto animalDto) {
		
		Animal animal = animalDto.conveter();
		animalRepository.save(animal);
		return "redirect:/";
	}	
	
	private List <DonoDto> retornaDonoDto() {
		var donoDto = new ArrayList<DonoDto>();
		donoRepository.findAll().forEach(d -> {
			donoDto.add(new DonoDto(d));
		
		});
		
		return donoDto;
	}
	
	private List <AnimalDto> retornAnimalDto() {
		var animalDto = new ArrayList<AnimalDto>();
		animalRepository.findAll().forEach(a -> {
			animalDto.add(new AnimalDto(a));
		
		});
	
		return animalDto;
	}
	
	@GetMapping("/deleta/{id}")
	public String deleta(@PathVariable int id) {
		animalRepository.deleteById(id);
		return "redirect:/";
	}
	
	@GetMapping("/edita/{id}")
	public String edita(@PathVariable int id, Model model) {
		
		var animalOptional = animalRepository.findById(id);
		if(animalOptional.isPresent()) {
			var animal = animalOptional.get();
			var animalDto = new AnimalDto(animal);
			model.addAttribute("animal", animalDto);
		}
		return "animal/novo";
	}
}
