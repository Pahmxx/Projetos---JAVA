package com.qintess.veterinaria.repositorios;

import org.springframework.data.repository.CrudRepository;

import com.qintess.veterinaria.models.Exame;

public interface ExameRepository extends CrudRepository<Exame, Integer>{


}
